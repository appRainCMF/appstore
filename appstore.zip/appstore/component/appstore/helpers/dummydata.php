<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_DummyData extends appRain_Base_Objects{

	public function install(){
		$this->CreateCategories()
		->AddByBatch();
	}
	
	public function AddByBatch(){
	
		$path = App::Config()->rootDir('/component/appstore/dbdata.sql');
		$data = App::Helper('Utility')->fatchfilecontent($path);
		$data = str_replace('{cid1}',$this->getPCatId1(),$data);
		$data = str_replace('{cid2}',$this->getPCatId2(),$data);
		
		$path2  = DATA . DS . 'dummydb.sql';
		App::Helper('Utility')->savefilecontent($path2,$data);
		
		App::Component('dbexpert')->Helper('Dbimexport')->import_path = $path2;
        App::Component('dbexpert')->Helper('Dbimexport')->import();  
		@unlink($path2);
	}
	
	public function CreateCategories(){
	
		# Product Category 1
		$id = $this->createCategory('product-cat','Cardigan & T-Shirt','cardigan_t-shirt_bannar.jpg');
		$this->setPCatId1($id);
		
		# Proudct Category 2		
		$id = $this->createCategory('product-cat','E-Books & Postcards','e-books_postcards_bannar.jpg');
		$this->setPCatId2($id);
		
		# Shipping Role 1
		$id = $this->createCategory('shippingrole','Cardigan','','a:2:{s:9:"Countries";a:237:{s:2:"AF";s:2:"15";s:2:"AL";s:2:"12";s:2:"DZ";s:2:"12";s:2:"AS";s:2:"15";s:2:"AD";s:2:"20";s:2:"AO";s:2:"27";s:2:"AI";s:2:"30";s:2:"AQ";s:2:"11";s:2:"AG";s:0:"";s:2:"AR";s:0:"";s:2:"AM";s:0:"";s:2:"AW";s:0:"";s:2:"AU";s:0:"";s:2:"AT";s:0:"";s:2:"AZ";s:0:"";s:2:"BS";s:0:"";s:2:"BH";s:0:"";s:2:"BD";s:0:"";s:2:"BB";s:0:"";s:2:"BY";s:0:"";s:2:"BE";s:0:"";s:2:"BZ";s:0:"";s:2:"BJ";s:0:"";s:2:"BM";s:0:"";s:2:"BT";s:0:"";s:2:"BO";s:0:"";s:2:"BA";s:0:"";s:2:"BW";s:0:"";s:2:"BV";s:0:"";s:2:"BR";s:0:"";s:2:"IO";s:0:"";s:2:"BN";s:0:"";s:2:"BG";s:0:"";s:2:"BF";s:0:"";s:2:"BI";s:0:"";s:2:"KH";s:0:"";s:2:"CM";s:0:"";s:2:"CA";s:0:"";s:2:"CV";s:0:"";s:2:"KY";s:0:"";s:2:"CF";s:0:"";s:2:"TD";s:0:"";s:2:"CL";s:0:"";s:2:"CN";s:0:"";s:2:"CX";s:0:"";s:2:"CS";s:0:"";s:2:"CO";s:0:"";s:2:"KM";s:0:"";s:2:"CG";s:0:"";s:2:"CK";s:0:"";s:2:"CR";s:0:"";s:2:"CI";s:0:"";s:2:"HR";s:0:"";s:2:"CU";s:0:"";s:2:"CC";s:0:"";s:2:"CY";s:0:"";s:2:"CZ";s:0:"";s:2:"DK";s:0:"";s:2:"DJ";s:0:"";s:2:"DM";s:0:"";s:2:"DO";s:0:"";s:2:"TP";s:0:"";s:2:"EC";s:0:"";s:2:"EG";s:0:"";s:2:"SV";s:0:"";s:2:"GQ";s:0:"";s:2:"ER";s:0:"";s:2:"EE";s:0:"";s:2:"ET";s:0:"";s:2:"FK";s:0:"";s:2:"FO";s:0:"";s:2:"FJ";s:0:"";s:2:"FI";s:0:"";s:2:"FR";s:0:"";s:2:"GF";s:0:"";s:2:"PF";s:0:"";s:2:"FT";s:0:"";s:2:"GA";s:0:"";s:2:"GM";s:0:"";s:2:"GE";s:0:"";s:2:"DE";s:0:"";s:2:"GH";s:0:"";s:2:"GI";s:0:"";s:2:"GR";s:0:"";s:2:"GL";s:0:"";s:2:"GD";s:0:"";s:2:"GP";s:0:"";s:2:"GU";s:0:"";s:2:"GT";s:0:"";s:2:"GN";s:0:"";s:2:"GW";s:0:"";s:2:"GY";s:0:"";s:2:"HT";s:0:"";s:2:"HE";s:0:"";s:2:"HN";s:0:"";s:2:"HK";s:0:"";s:2:"HU";s:0:"";s:2:"IS";s:0:"";s:2:"IN";s:0:"";s:2:"ID";s:0:"";s:2:"IR";s:0:"";s:2:"IQ";s:0:"";s:2:"IE";s:0:"";s:2:"IL";s:0:"";s:2:"IT";s:0:"";s:2:"JM";s:0:"";s:2:"JP";s:0:"";s:2:"JO";s:0:"";s:2:"KZ";s:0:"";s:2:"KE";s:0:"";s:2:"KI";s:0:"";s:2:"KP";s:0:"";s:2:"KO";s:0:"";s:2:"KW";s:0:"";s:2:"KG";s:0:"";s:2:"LO";s:0:"";s:2:"LV";s:0:"";s:2:"LB";s:0:"";s:2:"LS";s:0:"";s:2:"LR";s:0:"";s:2:"LY";s:0:"";s:2:"LI";s:0:"";s:2:"LT";s:0:"";s:2:"LU";s:0:"";s:2:"MO";s:0:"";s:2:"MK";s:0:"";s:2:"MG";s:0:"";s:2:"MW";s:0:"";s:2:"MY";s:0:"";s:2:"MV";s:0:"";s:2:"ML";s:0:"";s:2:"MT";s:0:"";s:2:"MH";s:0:"";s:2:"MQ";s:0:"";s:2:"MR";s:0:"";s:2:"MU";s:0:"";s:2:"YT";s:0:"";s:2:"MX";s:0:"";s:2:"MI";s:0:"";s:2:"MD";s:0:"";s:2:"MC";s:0:"";s:2:"MN";s:0:"";s:2:"ME";s:0:"";s:2:"MS";s:0:"";s:2:"MA";s:0:"";s:2:"MZ";s:0:"";s:2:"MM";s:0:"";s:2:"NA";s:0:"";s:2:"NR";s:0:"";s:2:"NP";s:0:"";s:2:"NL";s:0:"";s:2:"AN";s:0:"";s:2:"NC";s:0:"";s:2:"NZ";s:0:"";s:2:"NI";s:0:"";s:2:"NE";s:0:"";s:2:"NG";s:0:"";s:2:"NU";s:0:"";s:2:"NF";s:0:"";s:2:"MP";s:0:"";s:2:"NO";s:0:"";s:2:"OM";s:0:"";s:2:"PK";s:0:"";s:2:"PW";s:0:"";s:2:"PA";s:0:"";s:2:"PG";s:0:"";s:2:"PU";s:0:"";s:2:"PE";s:0:"";s:2:"PH";s:0:"";s:2:"PN";s:0:"";s:2:"PL";s:0:"";s:2:"PT";s:0:"";s:2:"PR";s:0:"";s:2:"QA";s:0:"";s:2:"RE";s:0:"";s:2:"RO";s:0:"";s:2:"RU";s:0:"";s:2:"RW";s:0:"";s:2:"SH";s:0:"";s:2:"KN";s:0:"";s:2:"LC";s:0:"";s:2:"SP";s:0:"";s:2:"VC";s:0:"";s:2:"WS";s:0:"";s:2:"SM";s:0:"";s:2:"ST";s:0:"";s:2:"SA";s:0:"";s:2:"SN";s:0:"";s:2:"EM";s:0:"";s:2:"SC";s:0:"";s:2:"SL";s:0:"";s:2:"SG";s:0:"";s:2:"SK";s:0:"";s:2:"SI";s:0:"";s:2:"SB";s:0:"";s:2:"SO";s:0:"";s:2:"ZA";s:0:"";s:2:"ES";s:0:"";s:2:"LK";s:0:"";s:2:"SD";s:0:"";s:2:"SR";s:0:"";s:2:"VB";s:0:"";s:2:"SZ";s:0:"";s:2:"SE";s:0:"";s:2:"CH";s:0:"";s:2:"SY";s:0:"";s:2:"TW";s:0:"";s:2:"TJ";s:0:"";s:2:"TZ";s:0:"";s:2:"TH";s:0:"";s:2:"TG";s:0:"";s:2:"TK";s:0:"";s:2:"TO";s:0:"";s:2:"TT";s:0:"";s:2:"TU";s:0:"";s:2:"TR";s:0:"";s:2:"TM";s:0:"";s:2:"TC";s:0:"";s:2:"TV";s:0:"";s:2:"UG";s:0:"";s:2:"UA";s:0:"";s:2:"AE";s:0:"";s:2:"GB";s:0:"";s:2:"US";s:0:"";s:2:"UY";s:0:"";s:2:"UZ";s:0:"";s:2:"VU";s:0:"";s:2:"VA";s:0:"";s:2:"VE";s:0:"";s:2:"VN";s:0:"";s:2:"VI";s:0:"";s:2:"WF";s:0:"";s:2:"EH";s:0:"";s:2:"YE";s:0:"";s:2:"ZR";s:0:"";s:2:"ZM";s:0:"";s:2:"ZW";s:0:"";}s:8:"Shipping";a:3:{s:11:"defaultrate";s:2:"10";s:9:"calmethod";s:13:"multiplybyqty";s:6:"script";s:0:"";}}');
		$this->setShippingRole1($id);
		
		# Shipping Role 2
		$id = $this->createCategory('shippingrole','T-Shirt','','a:2:{s:9:"Countries";a:237:{s:2:"AF";s:0:"";s:2:"AL";s:0:"";s:2:"DZ";s:0:"";s:2:"AS";s:0:"";s:2:"AD";s:0:"";s:2:"AO";s:0:"";s:2:"AI";s:0:"";s:2:"AQ";s:0:"";s:2:"AG";s:0:"";s:2:"AR";s:0:"";s:2:"AM";s:0:"";s:2:"AW";s:0:"";s:2:"AU";s:0:"";s:2:"AT";s:0:"";s:2:"AZ";s:0:"";s:2:"BS";s:0:"";s:2:"BH";s:0:"";s:2:"BD";s:0:"";s:2:"BB";s:0:"";s:2:"BY";s:0:"";s:2:"BE";s:0:"";s:2:"BZ";s:0:"";s:2:"BJ";s:0:"";s:2:"BM";s:0:"";s:2:"BT";s:0:"";s:2:"BO";s:0:"";s:2:"BA";s:0:"";s:2:"BW";s:0:"";s:2:"BV";s:0:"";s:2:"BR";s:0:"";s:2:"IO";s:0:"";s:2:"BN";s:0:"";s:2:"BG";s:0:"";s:2:"BF";s:0:"";s:2:"BI";s:0:"";s:2:"KH";s:0:"";s:2:"CM";s:0:"";s:2:"CA";s:0:"";s:2:"CV";s:0:"";s:2:"KY";s:0:"";s:2:"CF";s:0:"";s:2:"TD";s:0:"";s:2:"CL";s:0:"";s:2:"CN";s:0:"";s:2:"CX";s:0:"";s:2:"CS";s:0:"";s:2:"CO";s:0:"";s:2:"KM";s:0:"";s:2:"CG";s:0:"";s:2:"CK";s:0:"";s:2:"CR";s:0:"";s:2:"CI";s:0:"";s:2:"HR";s:0:"";s:2:"CU";s:0:"";s:2:"CC";s:0:"";s:2:"CY";s:0:"";s:2:"CZ";s:0:"";s:2:"DK";s:0:"";s:2:"DJ";s:0:"";s:2:"DM";s:0:"";s:2:"DO";s:0:"";s:2:"TP";s:0:"";s:2:"EC";s:0:"";s:2:"EG";s:0:"";s:2:"SV";s:0:"";s:2:"GQ";s:0:"";s:2:"ER";s:0:"";s:2:"EE";s:0:"";s:2:"ET";s:0:"";s:2:"FK";s:0:"";s:2:"FO";s:0:"";s:2:"FJ";s:0:"";s:2:"FI";s:0:"";s:2:"FR";s:0:"";s:2:"GF";s:0:"";s:2:"PF";s:0:"";s:2:"FT";s:0:"";s:2:"GA";s:0:"";s:2:"GM";s:0:"";s:2:"GE";s:0:"";s:2:"DE";s:0:"";s:2:"GH";s:0:"";s:2:"GI";s:0:"";s:2:"GR";s:0:"";s:2:"GL";s:0:"";s:2:"GD";s:0:"";s:2:"GP";s:0:"";s:2:"GU";s:0:"";s:2:"GT";s:0:"";s:2:"GN";s:0:"";s:2:"GW";s:0:"";s:2:"GY";s:0:"";s:2:"HT";s:0:"";s:2:"HE";s:0:"";s:2:"HN";s:0:"";s:2:"HK";s:0:"";s:2:"HU";s:0:"";s:2:"IS";s:0:"";s:2:"IN";s:0:"";s:2:"ID";s:0:"";s:2:"IR";s:0:"";s:2:"IQ";s:0:"";s:2:"IE";s:0:"";s:2:"IL";s:0:"";s:2:"IT";s:0:"";s:2:"JM";s:0:"";s:2:"JP";s:0:"";s:2:"JO";s:0:"";s:2:"KZ";s:0:"";s:2:"KE";s:0:"";s:2:"KI";s:0:"";s:2:"KP";s:0:"";s:2:"KO";s:0:"";s:2:"KW";s:0:"";s:2:"KG";s:0:"";s:2:"LO";s:0:"";s:2:"LV";s:0:"";s:2:"LB";s:0:"";s:2:"LS";s:0:"";s:2:"LR";s:0:"";s:2:"LY";s:0:"";s:2:"LI";s:0:"";s:2:"LT";s:0:"";s:2:"LU";s:0:"";s:2:"MO";s:0:"";s:2:"MK";s:0:"";s:2:"MG";s:0:"";s:2:"MW";s:0:"";s:2:"MY";s:0:"";s:2:"MV";s:0:"";s:2:"ML";s:0:"";s:2:"MT";s:0:"";s:2:"MH";s:0:"";s:2:"MQ";s:0:"";s:2:"MR";s:0:"";s:2:"MU";s:0:"";s:2:"YT";s:0:"";s:2:"MX";s:0:"";s:2:"MI";s:0:"";s:2:"MD";s:0:"";s:2:"MC";s:0:"";s:2:"MN";s:0:"";s:2:"ME";s:0:"";s:2:"MS";s:0:"";s:2:"MA";s:0:"";s:2:"MZ";s:0:"";s:2:"MM";s:0:"";s:2:"NA";s:0:"";s:2:"NR";s:0:"";s:2:"NP";s:0:"";s:2:"NL";s:0:"";s:2:"AN";s:0:"";s:2:"NC";s:0:"";s:2:"NZ";s:0:"";s:2:"NI";s:0:"";s:2:"NE";s:0:"";s:2:"NG";s:0:"";s:2:"NU";s:0:"";s:2:"NF";s:0:"";s:2:"MP";s:0:"";s:2:"NO";s:0:"";s:2:"OM";s:0:"";s:2:"PK";s:0:"";s:2:"PW";s:0:"";s:2:"PA";s:0:"";s:2:"PG";s:0:"";s:2:"PU";s:0:"";s:2:"PE";s:0:"";s:2:"PH";s:0:"";s:2:"PN";s:0:"";s:2:"PL";s:0:"";s:2:"PT";s:0:"";s:2:"PR";s:0:"";s:2:"QA";s:0:"";s:2:"RE";s:0:"";s:2:"RO";s:0:"";s:2:"RU";s:0:"";s:2:"RW";s:0:"";s:2:"SH";s:0:"";s:2:"KN";s:0:"";s:2:"LC";s:0:"";s:2:"SP";s:0:"";s:2:"VC";s:0:"";s:2:"WS";s:0:"";s:2:"SM";s:0:"";s:2:"ST";s:0:"";s:2:"SA";s:0:"";s:2:"SN";s:0:"";s:2:"EM";s:0:"";s:2:"SC";s:0:"";s:2:"SL";s:0:"";s:2:"SG";s:0:"";s:2:"SK";s:0:"";s:2:"SI";s:0:"";s:2:"SB";s:0:"";s:2:"SO";s:0:"";s:2:"ZA";s:0:"";s:2:"ES";s:0:"";s:2:"LK";s:0:"";s:2:"SD";s:0:"";s:2:"SR";s:0:"";s:2:"VB";s:0:"";s:2:"SZ";s:0:"";s:2:"SE";s:0:"";s:2:"CH";s:0:"";s:2:"SY";s:0:"";s:2:"TW";s:0:"";s:2:"TJ";s:0:"";s:2:"TZ";s:0:"";s:2:"TH";s:0:"";s:2:"TG";s:0:"";s:2:"TK";s:0:"";s:2:"TO";s:0:"";s:2:"TT";s:0:"";s:2:"TU";s:0:"";s:2:"TR";s:0:"";s:2:"TM";s:0:"";s:2:"TC";s:0:"";s:2:"TV";s:0:"";s:2:"UG";s:0:"";s:2:"UA";s:0:"";s:2:"AE";s:0:"";s:2:"GB";s:0:"";s:2:"US";s:0:"";s:2:"UY";s:0:"";s:2:"UZ";s:0:"";s:2:"VU";s:0:"";s:2:"VA";s:0:"";s:2:"VE";s:0:"";s:2:"VN";s:0:"";s:2:"VI";s:0:"";s:2:"WF";s:0:"";s:2:"EH";s:0:"";s:2:"YE";s:0:"";s:2:"ZR";s:0:"";s:2:"ZM";s:0:"";s:2:"ZW";s:0:"";}s:8:"Shipping";a:3:{s:11:"defaultrate";s:2:"10";s:9:"calmethod";s:11:"same4allqty";s:6:"script";s:0:"";}}');
		$this->setShippingRole2($id);
		
		# Shipping Role 3
		$id = $this->createCategory('shippingrole','Postcards','','a:2:{s:9:"Countries";a:237:{s:2:"AF";s:0:"";s:2:"AL";s:0:"";s:2:"DZ";s:0:"";s:2:"AS";s:0:"";s:2:"AD";s:0:"";s:2:"AO";s:0:"";s:2:"AI";s:0:"";s:2:"AQ";s:0:"";s:2:"AG";s:0:"";s:2:"AR";s:0:"";s:2:"AM";s:0:"";s:2:"AW";s:0:"";s:2:"AU";s:0:"";s:2:"AT";s:0:"";s:2:"AZ";s:0:"";s:2:"BS";s:0:"";s:2:"BH";s:0:"";s:2:"BD";s:0:"";s:2:"BB";s:0:"";s:2:"BY";s:0:"";s:2:"BE";s:0:"";s:2:"BZ";s:0:"";s:2:"BJ";s:0:"";s:2:"BM";s:0:"";s:2:"BT";s:0:"";s:2:"BO";s:0:"";s:2:"BA";s:0:"";s:2:"BW";s:0:"";s:2:"BV";s:0:"";s:2:"BR";s:0:"";s:2:"IO";s:0:"";s:2:"BN";s:0:"";s:2:"BG";s:0:"";s:2:"BF";s:0:"";s:2:"BI";s:0:"";s:2:"KH";s:0:"";s:2:"CM";s:0:"";s:2:"CA";s:0:"";s:2:"CV";s:0:"";s:2:"KY";s:0:"";s:2:"CF";s:0:"";s:2:"TD";s:0:"";s:2:"CL";s:0:"";s:2:"CN";s:0:"";s:2:"CX";s:0:"";s:2:"CS";s:0:"";s:2:"CO";s:0:"";s:2:"KM";s:0:"";s:2:"CG";s:0:"";s:2:"CK";s:0:"";s:2:"CR";s:0:"";s:2:"CI";s:0:"";s:2:"HR";s:0:"";s:2:"CU";s:0:"";s:2:"CC";s:0:"";s:2:"CY";s:0:"";s:2:"CZ";s:0:"";s:2:"DK";s:0:"";s:2:"DJ";s:0:"";s:2:"DM";s:0:"";s:2:"DO";s:0:"";s:2:"TP";s:0:"";s:2:"EC";s:0:"";s:2:"EG";s:0:"";s:2:"SV";s:0:"";s:2:"GQ";s:0:"";s:2:"ER";s:0:"";s:2:"EE";s:0:"";s:2:"ET";s:0:"";s:2:"FK";s:0:"";s:2:"FO";s:0:"";s:2:"FJ";s:0:"";s:2:"FI";s:0:"";s:2:"FR";s:0:"";s:2:"GF";s:0:"";s:2:"PF";s:0:"";s:2:"FT";s:0:"";s:2:"GA";s:0:"";s:2:"GM";s:0:"";s:2:"GE";s:0:"";s:2:"DE";s:0:"";s:2:"GH";s:0:"";s:2:"GI";s:0:"";s:2:"GR";s:0:"";s:2:"GL";s:0:"";s:2:"GD";s:0:"";s:2:"GP";s:0:"";s:2:"GU";s:0:"";s:2:"GT";s:0:"";s:2:"GN";s:0:"";s:2:"GW";s:0:"";s:2:"GY";s:0:"";s:2:"HT";s:0:"";s:2:"HE";s:0:"";s:2:"HN";s:0:"";s:2:"HK";s:0:"";s:2:"HU";s:0:"";s:2:"IS";s:0:"";s:2:"IN";s:0:"";s:2:"ID";s:0:"";s:2:"IR";s:0:"";s:2:"IQ";s:0:"";s:2:"IE";s:0:"";s:2:"IL";s:0:"";s:2:"IT";s:0:"";s:2:"JM";s:0:"";s:2:"JP";s:0:"";s:2:"JO";s:0:"";s:2:"KZ";s:0:"";s:2:"KE";s:0:"";s:2:"KI";s:0:"";s:2:"KP";s:0:"";s:2:"KO";s:0:"";s:2:"KW";s:0:"";s:2:"KG";s:0:"";s:2:"LO";s:0:"";s:2:"LV";s:0:"";s:2:"LB";s:0:"";s:2:"LS";s:0:"";s:2:"LR";s:0:"";s:2:"LY";s:0:"";s:2:"LI";s:0:"";s:2:"LT";s:0:"";s:2:"LU";s:0:"";s:2:"MO";s:0:"";s:2:"MK";s:0:"";s:2:"MG";s:0:"";s:2:"MW";s:0:"";s:2:"MY";s:0:"";s:2:"MV";s:0:"";s:2:"ML";s:0:"";s:2:"MT";s:0:"";s:2:"MH";s:0:"";s:2:"MQ";s:0:"";s:2:"MR";s:0:"";s:2:"MU";s:0:"";s:2:"YT";s:0:"";s:2:"MX";s:0:"";s:2:"MI";s:0:"";s:2:"MD";s:0:"";s:2:"MC";s:0:"";s:2:"MN";s:0:"";s:2:"ME";s:0:"";s:2:"MS";s:0:"";s:2:"MA";s:0:"";s:2:"MZ";s:0:"";s:2:"MM";s:0:"";s:2:"NA";s:0:"";s:2:"NR";s:0:"";s:2:"NP";s:0:"";s:2:"NL";s:0:"";s:2:"AN";s:0:"";s:2:"NC";s:0:"";s:2:"NZ";s:0:"";s:2:"NI";s:0:"";s:2:"NE";s:0:"";s:2:"NG";s:0:"";s:2:"NU";s:0:"";s:2:"NF";s:0:"";s:2:"MP";s:0:"";s:2:"NO";s:0:"";s:2:"OM";s:0:"";s:2:"PK";s:0:"";s:2:"PW";s:0:"";s:2:"PA";s:0:"";s:2:"PG";s:0:"";s:2:"PU";s:0:"";s:2:"PE";s:0:"";s:2:"PH";s:0:"";s:2:"PN";s:0:"";s:2:"PL";s:0:"";s:2:"PT";s:0:"";s:2:"PR";s:0:"";s:2:"QA";s:0:"";s:2:"RE";s:0:"";s:2:"RO";s:0:"";s:2:"RU";s:0:"";s:2:"RW";s:0:"";s:2:"SH";s:0:"";s:2:"KN";s:0:"";s:2:"LC";s:0:"";s:2:"SP";s:0:"";s:2:"VC";s:0:"";s:2:"WS";s:0:"";s:2:"SM";s:0:"";s:2:"ST";s:0:"";s:2:"SA";s:0:"";s:2:"SN";s:0:"";s:2:"EM";s:0:"";s:2:"SC";s:0:"";s:2:"SL";s:0:"";s:2:"SG";s:0:"";s:2:"SK";s:0:"";s:2:"SI";s:0:"";s:2:"SB";s:0:"";s:2:"SO";s:0:"";s:2:"ZA";s:0:"";s:2:"ES";s:0:"";s:2:"LK";s:0:"";s:2:"SD";s:0:"";s:2:"SR";s:0:"";s:2:"VB";s:0:"";s:2:"SZ";s:0:"";s:2:"SE";s:0:"";s:2:"CH";s:0:"";s:2:"SY";s:0:"";s:2:"TW";s:0:"";s:2:"TJ";s:0:"";s:2:"TZ";s:0:"";s:2:"TH";s:0:"";s:2:"TG";s:0:"";s:2:"TK";s:0:"";s:2:"TO";s:0:"";s:2:"TT";s:0:"";s:2:"TU";s:0:"";s:2:"TR";s:0:"";s:2:"TM";s:0:"";s:2:"TC";s:0:"";s:2:"TV";s:0:"";s:2:"UG";s:0:"";s:2:"UA";s:0:"";s:2:"AE";s:0:"";s:2:"GB";s:0:"";s:2:"US";s:0:"";s:2:"UY";s:0:"";s:2:"UZ";s:0:"";s:2:"VU";s:0:"";s:2:"VA";s:0:"";s:2:"VE";s:0:"";s:2:"VN";s:0:"";s:2:"VI";s:0:"";s:2:"WF";s:0:"";s:2:"EH";s:0:"";s:2:"YE";s:0:"";s:2:"ZR";s:0:"";s:2:"ZM";s:0:"";s:2:"ZW";s:0:"";}s:8:"Shipping";a:3:{s:11:"defaultrate";s:1:"0";s:9:"calmethod";s:11:"setbyscript";s:6:"script";s:339:"switch($Shipping->getCountry()){
    case "US":
      if($Shipping->getQty() < 5 ) return 10;
      else return $Shipping->getQty() * 2;
      break;
    case "CA": 
      if($Shipping->getQty() < 5 ) return 12;
      else return $Shipping->getQty() * 3;
      break;	  
    default: 	
      return $Shipping->getQty() * 5;   
}";}}');
		$this->setShippingRole3($id);
		
		return $this;
	}
	
	public function createCategory($type=null,$title='',$image='',$description='')
	{
		$Admin = App::Module('Admin')->thisAdminInfo();
		$CData = App::CategorySet($type)->findByTitle($title);
		if(empty($CData)){
			$Obj = App::Model('Category')
				->setId(null)
				->setAdminRef($Admin['id'])
				->setTitle($title)
				->setImage($image)
				->setType($type)
				->setDescription($description)
				->setEntryDate(date('Y-m-d h:i:s'))
				->Save();
			return $Obj->getId();
		}	
		else {
			return $CData['id'];
		}
	}
	
	public function createDefaultSettings($soption='',$svalue='',$section=null){
	
		$Config = App::Model('Config')->findBySoption($soption);
		
		if(empty($Config)){			
			App::Model('Config')
				->setId(null)
				->setSoption($soption)
				->setSvalue($svalue)
				->setSection($section)
				->Save();
		}
	}
	
	public function generateCommonData(){
	
	    App::Component('dbexpert')->Helper('Dbimexport')->import_path = App::Config()->rootDir('/component/appstore/basedb.sql');
        App::Component('dbexpert')->Helper('Dbimexport')->import();  
		
		# Settings 
		$this->createDefaultSettings('invoice_title','Invoice','paymentmethod');		
		$this->createDefaultSettings('invoice_checkut_message','The order will auto approve.','paymentmethod');		
		$this->createDefaultSettings('invoice_payment_status','Paid','paymentmethod');		
		$this->createDefaultSettings('invoice_status','Active','paymentmethod');			
		$this->createDefaultSettings('appstoresettings_contact_address_1_title','Order Inquiry','appstoresettings');
		$this->createDefaultSettings('appstoresettings_contact_address_1',"Sednisl Imperdiet\n45/A Sit amet dapibus\nDictum adipiscing,diam\nsednisl@cmperdiet.com\n012-3456789",'appstoresettings');
		$this->createDefaultSettings('appstoresettings_contact_address_2_title','Customer Care','appstoresettings');
		$this->createDefaultSettings('appstoresettings_contact_address_2',"Nunc Adipiscing\n89-L/A Psum Eu Nibh\nSollicitudin Congue\narcu@ultrices.net\n033-3456789",'appstoresettings');
		$this->createDefaultSettings('currency','$','opts');		
		
		
		# Email Template
		App::Module('EmailTemplate')
			->Load(
				array(
					'templateType'=>'InventoryReachedCriticalQuantity',
					'subject' => 'Refill your inventory urgently',
					'message'=>"Dear Concern,\nFollowing product has  reached critical quantity. Refill your inventory urgently. \n\n<strong>Product Information:</strong>\nID:{id}, Name: {title}, Qty:  {qty}\n\n<hr />\n" 
								. '<a href="{baseurl}/admin"></a>'
				)
			);
		App::Module('EmailTemplate')
			->Load(
				array(
					'templateType'=>'InventoryAdjusted',
					'subject' => 'Inventory has been adjusted',
					'message'=>"Dear Concern,\nFollowing product has been adjusted. \n\n<strong>Product Name:</strong>\n {title} \n<strong>Quantity Reached:</strong>\n {qty} \n\n\n<hr />\n" 
								. '<a href="{baseurl}/admin">View Admin Panel</a>'
				)
			);
			
		App::Module('EmailTemplate')
			->Load(
				array(
					'templateType'=>'StorePaymentSuccessAdmin',
					'subject' => 'One Order completed successfully',
					'message'=>"Dear Admin,\nOrder has been completed successfully. Please find the attached invoice.\n\nYou order is id : {OrderId}.\n\n\n<hr />\n"
								. '<a href="{baseurl}">View Website</a>' 
								. "\n" 
								.'<a href="{baseurl}/admin">Admin Panel</a>'
				)
			);	
			
		App::Module('EmailTemplate')
			->Load(
				array(
					'templateType'=>'StorePaymentSuccessCustomer',
					'subject' => 'Order completed successfully',
					'message'=>"Dear Customer,\nCongratulation! Order has been completed successfully. Please find the attached invoice.\n\nYou order is id : {OrderId}.\n\nPlease contact us at info@example.com or call us at 0123456789 for any further assistance.\n\n\n<hr />\n"
								. '<a href="{baseurl}">View Website</a>' 
								. "\n" 
								.'<a href="{baseurl}/admin">Admin Panel</a>'
				)
			);
			
		App::Module('EmailTemplate')
			->Load(
				array(
					'templateType'=>'StorePaymentFailedAdmin',
					'subject' => 'One Order completed unsuccessfully',
					'message'=>"Dear Admin,\nOne of the order has been unsuccessful. Please take necessary Steps\n"
								. 'Order Id: {OrderId} <a href="{baseurl}/managestore/orders/view/{OrderId}">View Order</a>'
								. "\nCustomer Information:\nName: {BillingFirstName} {BillingLastName} unsuccessfully \nEmail: {BillingEmail}\nPhone No: {BillingPhone}\n\n\n<hr />\n"
								. '<a href="{baseurl}">View Website</a>' 
								. "\n" 
								.'<a href="{baseurl}/admin">Admin Panel</a>'
				)
			);
			
		App::Module('EmailTemplate')
			->Load(
				array(
					'templateType'=>'StorePaymentFailedCustomer',
					'subject' => 'Order unsuccessful notification',
					'message'=>"Dear Customer,\nUnfortunately your payment did not complete successfully.\n"
								. "Order Id: {OrderId}\n\nPlease contact us at info@example.com or call us at 0123456789 for any further assistance.\n\n\n<hr />\n"
								. '<a href="{baseurl}">View Website</a>' 
								. "\n" 
								.'<a href="{baseurl}/admin">Admin Panel</a>'
				)
			);			
			
		# Page Manager Data
		App::PageManager()
		   ->setPagetitle ('Thank you! Payment Process completed successfully')
		   ->setTitle('Payment Success')
		   ->setContent('<h1>Thank you</h1><p>The payment process has been completed successfully. Please check your email for the invoice.</p><p><strong>Please contact us at info@example.com or call at +880123456789 for any query. <br />	</strong></p>')
		   ->LoadInDB('payment-success');

		App::PageManager()
			->setPagetitle ('Unfortunately the payment did not go trough.')
		   ->setTitle('Payment Failed')
		   ->setContent('<h2>Payment Failed</h2><p>Unfortunately the payment did not go through correctly. Please contact us at info@example.com or call at +880123456789</p><p><a href="{baseurl}/appstore/checkout">Check here to try checkout process again.</a></p>')
		   ->LoadInDB('payment-failed');
		
		App::PageManager()
		   ->setPagetitle('Demo Store, for easy shopping!')
		   ->setMetaKeywords('Online Store, E-Commerce, Shopping, Application, Component')
		   ->setMetaDescription ('This is an application of appRin Contenet Management Framewrok.')
		   ->setTitle('Store')
		   ->LoadInDB('store');

		App::PageManager()
			->setPageTitle('Checkout, Demo Store, for easy shopping!')
			->setMetaKeywords('Online Store, E-Commerce, Shopping, Application, Component')
			->setMetaDescription ('This is an application of appRin Contenet Management Framewrok.')
			->setTitle('Checkout')
			->LoadInDB('checkout');
	}
}
