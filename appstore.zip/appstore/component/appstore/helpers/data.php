<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_Data extends appRain_Base_Objects
{
    const _minitem = 1;
    const _itemremovelimit = 0;
    const STATUS_PENDING = 'Pending';
    const STATUS_PROCESSING = 'Processing';
    const STATUS_COMPLETE = 'Complete';
    const STATUS_PAID = 'Paid';
	const DEFULT_CURR = 'USD';
	const DATA_SOURCE = DATA;
	public $cartMessage = array(
		"SOLD" => "This item has been sold out",
		"DEFAULT" => "Please try other combination"
	);
	
    public  $enablepaymentprocessor = true;
    private $itemtotal = null;

    /**
     * Get Payment status in Array
     */
    public function getPaymentStatusList()
    {
        return Array(
            self::STATUS_PENDING=>self::STATUS_PENDING,
            self::STATUS_PAID=>self::STATUS_PAID
        );
    }

    /**
     * Get Delivery stats in Array
     */
    public function getDeliveryStatusList()
    {
        return Array(
            self::STATUS_PENDING=>self::STATUS_PENDING,
            self::STATUS_PROCESSING=>self::STATUS_PROCESSING,
            self::STATUS_COMPLETE=>self::STATUS_COMPLETE
        );
    }

    /**
     * Add Item
     */
    public function quickAdd($pid=null, $qty=null)
    {
        $this->cleartotalItem();

        if(!isset($pid) || !isset($qty)){
            throw new AppException($this->__("System error, Please try after a few moment."));
            return ;
        }

        $cartInfo = $this->getCartInfo();
        if($qty == self::_itemremovelimit){
			unset($cartInfo[$pid]);
		}
        else {
			
			$attrData = $this->attributePost2List($this->getAttribute(),$pid);
			if($attrData['maxqty'] !=='' and $attrData['maxqty'] < $qty){
				throw new AppException($this->__(" Available quantity of this product is " . $attrData['maxqty']));
				return ;
			}
		   
			$cartInfo[$pid] = array(
				"qty" => $qty,
				"attributes" => $attrData['attributes']
			);
		}
        
		App::Module('Session')->write('appcart',$cartInfo);

        return $this;
    }
	
    public function buyNowButton($val=null){
       
        $str ='';
        $str =  '
                <a href="' . App::Config()->baseUrl("/item-detail/{$val['id']}/" . App::Helper('Utility')->text2Normalize($val['title'])) . '" class="btn btn-warning btn-sm">Buy Now</a>
                
                
                
               ';
        /*
        $str =  '<div class="btn-group">
                <a href="' . App::Config()->baseUrl("/item-detail/{$val['id']}/" . App::Helper('Utility')->text2Normalize($val['title'])) . '" class="btn btn-warning btn-sm">Buy Now</a>
                <button data-toggle="dropdown" class="btn btn-primary dropdown-toggle btn-sm" type="button">
                <span class="caret"></span>
                </button>
                <ul aria-labelledby="dropdownMenu1" role="menu" class="dropdown-menu">';
                
            if(App::Component('Members')->Helper('Auth')->isLoggedIn()){  
                $str .=    '<li ><a href="javascript:void(0)" iteamid="' . $val['id'] .  '" class="wishlistrequest" role="menuitem">Add to Wishlist</a></li>
                    <li ><a href="javascript:void(0)" iteamid="' . $val['id'] .  '" class="suggest-a-friend" role="menuitem">Suggest a Friend</a></li>
                    <li ><a href="javascript:void(0)" iteamid="' . $val['id'] .  '" class="request-to-play" role="menuitem">Send Game Request</a></li>';
            }
            else{
                $str .=    '<li ><a href="javascript:void(0)" iteamid="' . $val['id'] .  '" class="loginrequest" role="menuitem">Add to Wishlist</a></li>
                    <li ><a href="javascript:void(0)" iteamid="' . $val['id'] .  '" class="loginrequest" role="menuitem">Suggest a Friend</a></li>
                    <li ><a href="javascript:void(0)" iteamid="' . $val['id'] .  '" class="loginrequest" role="menuitem">Send Game Request</a></li>';
            }
            
            $str .=  '</ul>
            </div>';*/
            
        return $str;
    }
	public function attributePost2List($post,$pid=null,$qty=null){
		$Product = App::InformationSet('product')->findById($pid);
		$attributevalue = unserialize($Product['attributevalue']);
		$maxQty='';
		$attributes = array();
		if(!empty($attributevalue)){
			foreach($attributevalue as $key=>$row){
				foreach($row['value'] as $i=>$v){
					if($v == $post[$key]){
						if($row['qty'][$i] !=''){
							if(($maxQty==='') or ($row['qty'][$i] < $maxQty)){
								$maxQty = $row['qty'][$i];
							}
						}
						$attributes[$key]['title'] = $row['title'];
						$attributes[$key]['value'] = $post[$key];
					}
				}
			}	
		}
		return array('maxqty'=>$maxQty,'attributes'=>$attributes);
	}

    /**
     *  Remove item from cart
     */
    public function removeItem($id=null)
    {
        $this->cleartotalItem();
        $cartInfo = $this->getCartInfo();

        if(isset($cartInfo[$id])) unset($cartInfo[$id]);

        App::Module('Session')->write('appcart',$cartInfo);
    }

    /**
     * Clear total item
     */
    public function cleartotalItem()
    {
        $this->itemtotal = null;
    }

    /**
     * Clear Cart from Session
     */
    public function clearcart()
    {
        $this->cleartotalItem();
        App::Module('Session')->delete('appcart');
        App::Module("Session")->delete("appOrderId");
		App::Module("Session")->delete("shipping_country_code");
		App::Module("Session")->delete("discount_id");
    }

    /**
     * Get cart infor by product id
     */
    public function getCartInfoByProductId($id=null)
    {
        $cartInfo = App::Module('Session')->read('appcart');
		
		if(isset($cartInfo[$id])){
			return $cartInfo[$id]['qty'];
		}
		else{
			return  App::Config()->setting('appstoresettings_default_in_cart',self::_minitem);
		}
    }

    /**
     * Get Cart Info
     */
    public function getCartInfo($pid = NULL)
    {
        $cartInfo = App::Module('Session')->read('appcart');

        if(isset($pid)){
            return isset($cartInfo[$pid]['qty']) ? $cartInfo[$pid]['qty'] : null;
        }
        else{
            return empty($cartInfo) ? array() : $cartInfo;
        }
    }

    /**
     * Get Total Item info
     */
    public function getCartTotalItem()
    {
        if(!isset($this->itemtotal)){
            $this->itemtotal = 0;
            foreach($this->getCartInfo() as $quote){
                $this->itemtotal += $quote['qty'];
            }
        }
        return $this->itemtotal;
    }

    /**
     * Simple validation
     */
    public function isToCheckout()
    {
        return ($this->getCartTotalItem() > 0) ? true : false;
    }

    /**
     * Render Order Information
     */
    public function renderShoppingCart()
    {
        $currency = App::Helper('Config')->setting('currency',self::DEFULT_CURR);

        $gandtotal = 0;
        $tqty = 0;
        $DataGrid = App::Module('DataGrid');
        foreach($this->getCartInfo() as $pid=>$quote){
			$qty = $quote['qty'];
            $tmp = Array();
            $product = App::InformationSet('product')->findById($pid);
            $tmp['title'] = $product['title'];
            $tmp['thumb'] = App::Helper('Html')->imgDTag(App::Helper('Config')->basedir("/uploads/filemanager/{$product['imagethumb']}"));
            $tmp['shortdesc'] = trim(strip_tags($product['shortdesc']));
            $tmp['qty'] = $qty;
            $tmp['price'] = "{$qty}x{$product['price']}";
            $tmp['subtotal'] = "{$currency}" . ' ' . ($qty * $product['price']);
            $gandtotal += ($qty * $product['price']);
            $tqty += $qty;
			
			$attributeStr = App::Component('appStore')->Helper('Common')->getItemAttributes($quote,'html');
			$desc = ($attributeStr!='') ? $attributeStr : $tmp['shortdesc'];
			$DataGrid->addRow(
                $tmp['thumb'],
                $tmp['title'],
                $desc,
                App::Html()->inputTag("data[qty][{$pid}]",$tmp['qty'],array('class'=>'checkoutqtybox')),
                $tmp['price'],
                $tmp['subtotal'],
                App::Helper('Html')->linkTag(App::Helper("Config")->baseurl("/checkout/removeitem/{$pid}"),App::Helper('Html')->imgTag(App::Helper('Config')->baseurl('/images/admin/remove.gif')))
              );
        }

        $DataGrid->setHeader(Array("","Name","Description","Quantity","Price","Sub Total",""))
             ->setFooter(Array("","&nbsp;","&nbsp;",App::Html()->submitTag("data[Checkout][update]","Update",array("class"=>"btn btn-default btn-sm")),"&nbsp;","{$currency}{$gandtotal}",""))
             ->Render();
		
    }

    /**
     * Check if order exists in Database
     */
    public function isOrderExistsInDB($id)
    {
        $data = App::Model('Order')->findById($id);

        return !empty($data);
    }

    /**
     * Retrive order id
     */
    public function getOrderId()
    {
        $orderid = App::Module("Session")->Read("appOrderId");

        return (isset($orderid) && $this->isOrderExistsInDB($orderid)) ? $orderid : null;
    }

    /**
     * Register order id in Session
     */
    public function register($id=null)
    {
        if($this->getOrderId() === null){
            App::Module("Session")->Write("appOrderId",$id);
        }

    }

    /**
     * Move first instance in database
     */
    private function moveOrderInstanceToDB()
    {
        $obj = App::Model('Order')
            ->setId($this->getOrderId())
            ->setOrderdate(App::Helper('Date')->getDate())
            ->Save();

        if($obj->getErrorInfo()){

            echo App::Module("Cryptography")->jsonEncode(array( "_status" =>"Error", "_message"=>$this->__('Invalid Order Post data')));
            exit;
        }
        else {
            $this->Register($obj->getId());
        }

        return $this;
    }

    /**
     * Move Items in Database
     */
    private function moveItemsToDB()
    {
        $cartinfo = $this->getCartInfo();
        $orderid = $this->getOrderId();

        $itemsindb = App::Model('Item')->findAllByOrderId($orderid);

        $clonecartinfo = $cartinfo;
        if(!empty($itemsindb['data'])){
            foreach($itemsindb['data'] as $item){
                if(in_array($item['productid'],array_keys($clonecartinfo))){
                    $this->updateItemByPid($item['productid'],$item['id']);
                    if(isset($clonecartinfo[$item['productid']]))unset($clonecartinfo[$item['productid']]);
                }
                else{
                    App::Model('Item')->DeleteById($item['id']);
                }
            }
        }

        if(!empty($clonecartinfo)){
            foreach($clonecartinfo as $pid => $qty){
                $this->updateItemByPid($pid);
            }
        }

        return $this;
    }

    /**
     * Update Item Information
     */
    private function updateItemByPid($pid=null,$itemid=null)
    {
        $product = App::InformationSet('product')->findById($pid);
		$CartInfo = $this->getCartInfo();
		$ProductInfo = $CartInfo[$pid];
		$Qty = $ProductInfo['qty'];
		$attributes = isset($ProductInfo['attributes']) ? serialize($ProductInfo['attributes']):'' ;
		$Order = App::Model('Order')->findById($this->getOrderId());
		$ShippingCost = 0;

		if($Order['shippingaddress'] != ''){
			$ShippingAddress = unserialize($Order['shippingaddress']);
			$ShippingCost = App::Component('AppStore')
				->Helper('Checkout')
				->setCountry($ShippingAddress['country'])
				->setQty($Qty)
				->calculateShippingByProduct($pid);
		}

        App::Model('Item')
            ->setId($itemid)
            ->setOrderid($this->getOrderId())
            ->setProductid($pid)
            ->setDated(App::Helper('Date')->getDate('Y-m-d H:i:s'))
            ->setTitle($product['title'])
            ->setUnitprice($product['price'])
            ->setQty($Qty)
			->setShippingcost($ShippingCost)
			->setAttributes($attributes)
            ->setTotalprice($product['price'] * $Qty)
            ->setProductdata(serialize($product))
            ->setStatus(self::STATUS_PENDING)
            ->Save();
    }

    /**
     * Calculate total Qty
     */
    public function totalQty($orderid=null)
    {
        if(!isset($orderid)){
            $orderid = $this->getOrderId();
        }
        $data = App::Model('Item')
            ->find(
                "orderid={$orderid}",
                null,
                "sum(qty) as total"
            );

        return $data['total'];
    }

    /**
     * Calculate total Cost
     */
    public function totalCost($orderid=null)
    {
        if(!isset($orderid)){
            $orderid = $this->getOrderId();
        }

        $Order = App::Model('Order')->findById($orderid);
		
        return $Order['totalcost'];
    }

    /**
     * Get Payment name from it's class
     */
    public function paymentMethodToStatusName($method)
    {
        try{
            return App::Component('appStore')->Helper("Pgateway_common")->getObject($method)->getStatusName();
        }
        catch(Exception $e){
            return $method;
        }

    }

    /**
     * Update order data completely
     */
    public function completeOrderUpdate()
    {
        $orderid = $this->getOrderId();
        $shippingadd = $this->getShippingAddress();
        $billingadd = $this->getBillingAddress();

        $method = $this->paymentMethodToStatusName($this->getPaymentMethod());

        if(!isset($orderid)){
            throw new AppException($this->__("Order Data is not formated"));
        }
        else{
            App::Model('Order')
               ->setId($orderid);
			
			if(!empty($shippingadd)){
				App::Model('Order')->setShippingaddress(serialize($shippingadd))
					->setShippingCost(App::Component('AppStore')->Helper('Checkout')->calculateShipping());
			}
			
			if(!empty($billingadd)){
				App::Model('Order')->setBillingaddress(serialize($billingadd));
			}
			
            App::Model('Order')->setPaymenttype($method)
               ->setQty($this->totalQty())
               ->setDiscount(App::Component('AppStore')->Helper('Checkout')->calculateDiscount())
               ->setDiscountId(App::Session()->Read('discount_id'))	   
			   ->setTotalcost(App::Component('AppStore')->Helper('Checkout')->calculateOrderTotal())
               ->Save();
        }

    }

    /**
     * Change the order status
     * bydefault the status is set to "Paid" for payment success
     */
    public function ChnageOrderStatus($orderid=NULL,$status=null,$isnotified=true)
    {
        if(!isset($orderid)) $orderid = $this->getOrderId();

        $Payment = App::Component('appStore')->Helper("Pgateway_common")->getObject($this->getPaymentmethod());	

        if(!isset($status)) $status =$Payment->paymentStatus();

        App::Model('Order')
            ->setId($orderid)
           ->setPaymentType($this->getPaymentType())
           ->setPaymentstatus($status)
           ->setDeliverystatus($Payment->shippingStatus())
           ->Save();
		   
		if($status == self::STATUS_PAID){
			$this->adjustInventoryByOrder($orderid);
		}
		
		$Invoice =	App::Component('appStore')
			->Helper('Invoice')
			->createInvoice($orderid);
	
        if($isnotified){
            $this->sendOrderMail($orderid,$status);
        }

        return $this;
    }
	
	public function adjustInventoryByOrder($Order,$decrease=null){

		if(!is_array($Order)){
			$Order = App::Model('Order')->findById($Order);
		}
		
		if($decrease === null){
			$decrease = ($Order['paymentstatus'] == self::STATUS_PAID);
		}
		
		$ItemArr = App::Model('Item')->findAllByOrderId($Order['id']);
		
		if(!empty($ItemArr['data'])){
			foreach($ItemArr['data'] as $row){
				$Product = App::InformationSet('Product')->findById($row['productid']);				
				if($Product['qty'] != ''){
					$attributevalues = unserialize($Product['attributevalue']);

					if(!empty($row['attributes']) && !empty($Product['attributevalue'])){
						$attributes = unserialize($row['attributes']);
						
						foreach($attributes as $key=>$attribute){
							if(is_array($attributevalues[$key]['value'])){
								foreach($attributevalues[$key]['value'] as $k=>$v){
									if($attributes[$key]['value'] == $v){
										if($decrease){
											$attributevalues[$key]['qty'][$k] -= $row['qty'];
										}
										else{
											$attributevalues[$key]['qty'][$k] += $row['qty'];
										}
									}
								}
							}
						}
					}

					$attributevalues = serialize($attributevalues);
					
					
					if($decrease){
						$qty = $Product['qty']-$row['qty'];
					}
					else{
						$qty = $Product['qty']+$row['qty'];
					}

					App::InformationSet('Product')
						->setId($row['productid'])
						->setAttributevalue($attributevalues)
						->setQty($qty)
						->Save();

					if(App::Helper('Config')->setting('appstoresettings_emailnotification','Yes') =='Yes'){	
					
						# Fetch Updated data to send in email
						$Product = App::InformationSet('Product')->findById($row['productid']);
						
						if($decrease){	
							if($Product['criticalqty'] != ''){
								if( $qty < $Product['criticalqty']){
									$obj = App::Helper('EmailTemplate')
										->setParameters($Product)
										->prepare('InventoryReachedCriticalQuantity',true);	
								}
								
							}
						}
						else{
							$obj = App::Helper('EmailTemplate')
								->setParameters($Product)
								->prepare('InventoryAdjusted',true);	
						}
					}
				}				
			}
		}
	}
	
	public function getAddressParam($address,$field){	
		return isset($address[$field]) ? $address[$field] : '';
	}
	

    /**
     * Send order notification
     * Notification text fetch from Email Template edited by Admin
     * Email Template Keywords
     * {FirstName} {LastName} {AddressLine1} {AddressLine2}
     * {Email} {Invoice} {Phone} {City} {State} {Zipcode} {Country}
     */
    public function sendOrderMail($orderid=NULL,$status=self::STATUS_PAID)
    {
        $emailnotification = App::Helper('Config')->setting('appstoresettings_emailnotification','Yes');

        if($emailnotification=='No'){
            return false;
        }

        if(!isset($orderid)) $orderid = $this->getOrderId();

        $orderData = App::Model('Order')->findById($orderid);
		
		$shippingaddress = array();
		if(isset($orderData['shippingaddress'])){
			$shippingaddress = unserialize($orderData['shippingaddress']);
		}
		$billingaddress = array();
		if(isset($orderData['billingaddress'])){
			$billingaddress = unserialize($orderData['billingaddress']);
		}

        $params = Array(
		    "OrderId"=> $orderid,
            "BillingFirstName" => $this->getAddressParam($billingaddress,'fname'),
            "BillingLastName" => $this->getAddressParam($billingaddress,'lname'),
            "BillingAddressLine1" => $this->getAddressParam($billingaddress,'address_line_1'),
            "BillingAddressLine2" => $this->getAddressParam($billingaddress,'address_line_2'),
            "BillingEmail" => $this->getAddressParam($billingaddress,'email'),            
            "BillingPhone" => $this->getAddressParam($billingaddress,'phoneno'),
            "BillingCity" => $this->getAddressParam($billingaddress,'city'),
            "BillingState" => $this->getAddressParam($billingaddress,'state'),
            "BillingZipcode" => $this->getAddressParam($billingaddress,'zipcode'),
            "BillingCountry" => App::Helper('Utility')->CountryCodeToName($this->getAddressParam($billingaddress,'country')),
			
            "ShippingFirstName" => $this->getAddressParam($shippingaddress,'fname'),
            "ShippingLastName" => $this->getAddressParam($shippingaddress,'lname'),
            "ShippingAddressLine1" => $this->getAddressParam($shippingaddress,'address_line_1'),
            "ShippingAddressLine2" => $this->getAddressParam($shippingaddress,'address_line_2'),
            "ShippingEmail" => $this->getAddressParam($shippingaddress,'email'),            
            "ShippingPhone" => $this->getAddressParam($shippingaddress,'phoneno'),
            "ShippingCity" => $this->getAddressParam($shippingaddress,'city'),
            "ShippingState" => $this->getAddressParam($shippingaddress,'state'),
            "ShippingZipcode" => $this->getAddressParam($shippingaddress,'zipcode'),
            "ShippingCountry" => App::Helper('Utility')->CountryCodeToName($this->getAddressParam($shippingaddress,'country'))
        );
		

        if($status==self::STATUS_PAID)
        {
			$path =	App::Component('appStore')->Helper('Invoice')->getFilePath($orderid);			
			App::Plugin('Mailing_PHPMailer')->AddAttachment($path,'Invoice.pdf');
		
			App::Helper('EmailTemplate')
                ->setParameters($params)
                ->prepare('StorePaymentSuccessAdmin',true);
			 	 						
           $obj= App::Helper('EmailTemplate')
                ->setParameters($params)
                ->setTo(
                    Array(
                        "{$billingaddress['email']}",
                        "{$billingaddress['fname']} {$billingaddress['lname']}"))
                ->prepare('StorePaymentSuccessCustomer',true);
				
			
        }
        else
        {
            App::Helper('EmailTemplate')
                ->setParameters($params)
                ->prepare('StorePaymentFailedAdmin',true);

            App::Helper('EmailTemplate')
                ->setParameters($params)
                ->setTo(
                    Array(
                        "{$shippingaddress['email']}",
                        "{$shippingaddress['fname']} {$shippingaddress['lname']}"))
                ->prepare('StorePaymentFailedCustomer',true);
        }
    }

    /**
     * Do more validation as per
     * Need
     */
    public function orderValidation()
    {
        if(!$this->isToCheckout())
        {
            echo App::Load("Module/Cryptography")->jsonEncode(array("_status" =>"Redirect","_location"=>App::Helper('Config')->baseUrl("/")));
            exit;
        }

        $this->verifyAddress()->verifyAddress('Shipping');

        return $this;
    }

    public function verifyAddress($type="Billing")
    {
        $address = ($type=="Billing")
            ? $this->getBillingAddress()
            : $this->getShippingAddress();
			
		if(!empty($address)){
			if(!App::Helper('Validation')->notEmpty($address['fname'])){
				throw new AppException($this->__("Please enter {$type} First Name"));
			}
			else if(!App::Helper('Validation')->notEmpty($address['lname'])){
				throw new AppException($this->__("Please enter {$type} Last Name"));
			}
			else if(!App::Helper('Validation')->notEmpty($address['address_line_1'])){
				throw new AppException($this->__("Please enter {$type} address line 1"));
			}
			else if(!App::Helper('Validation')->notEmpty($address['city'])){
				throw new AppException($this->__("Please enter {$type} valid city"));
			}
			else if(!App::Helper('Validation')->notEmpty($address['state'])){
				throw new AppException($this->__("Please enter {$type} valid state"));
			}
			else if(!App::Helper('Validation')->email($address['email'])){
				throw new AppException($this->__("Please enter {$type} valid email address"));
			}
			else if(!App::Helper('Validation')->notEmpty($address['country'])){
				throw new AppException($this->__("Please enter {$type} valid select country"));
			}
		}
        return $this;
    }

    public function organiseResource()
    {
        $data = $this->getCheckoutPostData();
		$data['Shipping'] = isset($data['Shipping']) ? $data['Shipping'] : array();
		$data['Billing'] = isset($data['Billing']) ? $data['Billing'] : array();
		
        $data['Checkout']['billintoshipgaddress'] = isset($data['Checkout']['billintoshipgaddress']) ? "Yes":"No";
		
        if($data['Checkout']['billintoshipgaddress'] == "Yes"){
            $data['Billing'] = $data['Shipping'];
        }

        $this->setBillToShippingAddress($data['Checkout']['billintoshipgaddress']);
        $this->setShippingAddress($data['Shipping']);
        $this->setBillingAddress($data['Billing']);
        if(!isset($data['Payment']['method'])){
            throw new AppException($this->__('Please select a payment method'));
        }
        $this->setPaymentMethod($data['Payment']['method']);
        $this->setPaymentData(isset($data['Payment'][$data['Payment']['method']]) ? $data['Payment'][$data['Payment']['method']] : Array());
        return $this;
    }

    public function StartCheckoutProcess()
    {
             // Move first Instance
             // of Quote in Data base
        $this->moveOrderInstanceToDB()
             // Move/Update Items
             // database
             ->moveItemsToDB()
             // Set Shipping address, Paymants method
             // by maginc methods and the more full
             // Order to database
             //---------------------------------------+
             ->completeOrderUpdate();

        if($this->enablepaymentprocessor){
            // Instantiate payment process class and execute.
            // We always expect a class with the pattern of
            // "Pgateway_PaymentMethod" For example "Pgateway_Paypal".
            // This class will auto load from "development/helper/pgateway".
            // Each payment class must have a method place() that will
            // execute form this point and do other task as per need
            // and for any invalid operation throw a exception that will
            // will catch from base checkout call try block in completeCheckoutAction()
            // -----------------------------------------------------------------------+
            App::Component('appStore')
                ->Helper("Pgateway_common")
                ->getObject($this->getPaymentMethod())
                ->setPaymentData($this->getPaymentData())
                ->setAmount($this->totalCost())
                ->setOrderId($this->getOrderId())
                ->setBillingAddress($this->getBillingAddress())
				->setShippingAddress($this->getShippingAddress())
                ->place();
        }
        return $this;
    }
	
	public function caregoryList(){
		$Category = App::CategorySet('product-cat')->findAll("1 ORDER BY title");
		return $Category['data'];
	}
	
	public function CountryList($status='all'){
	
		if(strtolower($status) == 'all'){
			$Countries = App::InformationSet('countries')->findAll('1 ORDER BY name ASC');
		}
		else {
			$Countries = App::InformationSet('countries')->findAll("shippingstatus='{$status}' ORDER BY name ASC");		}

		return ($Countries['data']);
	}
	
	public function currencyFormate($v=0){
		if(is_numeric($v)){
			return number_format($v,2);
		}
	}
	
	public function getCartMessage($Code){
		return isset($this->cartMessage[$Code]) ? $this->__($this->cartMessage[$Code]) : $this->__($this->cartMessage['DEFAULT']);
	}
	
	public function getResourcePath($select='invoice'){
	
		if(!is_writable(self::DATA_SOURCE)){
			pr(self::DATA_SOURCE . ' is not writeable');
		}
		
		$P = self::DATA_SOURCE . DS . 'appstore';
		
		if(!file_exists($P)){
			App::Utility()->createDir($P);
		}
		
		if(strtolower($select)=='invoice'){
			$PA = $P . DS . 'invoice';
			if(!file_exists($PA)){
				App::Utility()->createDir($PA);
			}
		}
		elseif(strtolower($select)=='virtualproduct'){
			$PA = $P . DS . 'virtualproductfiles';
			if(!file_exists($PA)){
				App::Utility()->createDir($PA);
			}
		}
		else{
			$PA = $P . DS . $select;
		}
		
		return $PA;
	}
}