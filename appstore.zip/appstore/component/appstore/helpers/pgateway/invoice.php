<?php
class Component_Appstore_Helpers_Pgateway_Invoice extends Component_Appstore_Helpers_Pgateway_Common
{
	const PAYMENT_SUCCESS_URL = '/payment-success';
	const STATUS_NAME = 'Invoice';

	public function place()
	{
       /* Simplying allow all */
	}

	public function getStatusName()
	{
		return self::STATUS_NAME;
	}

    public function htmlToRender()
    {
        return App::Config()->Setting('invoice_checkut_message',"The order will be pending for approval.");
    }

    public function paymentStatus()
    {
        return App::Config()->Setting('invoice_payment_status',Component_Appstore_Helpers_Data::STATUS_PENDING);
    }
}