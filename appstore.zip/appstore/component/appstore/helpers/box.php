<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_Box extends appRain_Base_Objects
{
	public function Charts(){
		$dataQty = App::Model('Order')->findAll('1 GROUP BY dt order by dt ASC limit 0,5',null,'count(*) as cnt, substr(orderdate,1,7) as dt');
		$data = App::Model('Order')->findAll('1 GROUP BY dt order by dt ASC limit 0,5',null,'sum(qty) as cnt, substr(orderdate,1,7) as dt');
		$Cntdata = App::Model('Order')->find('1 GROUP BY dt order by cnt DESC limit 0,5',null,'sum(qty) as cnt, substr(orderdate,1,7) as dt');
		$str =
		'<div class="chart">
			<ul class="bar-outer">';
				$str1 = '';
				$str2 = '';
				if(!empty($data['data'])){
					$Coefficient  = (200/$Cntdata['cnt']);
					foreach($data['data'] as $key=>$row){
						$height = round(($Coefficient*$row['cnt']));
						$topMargin = (200-$height);
						$str1 .= '<li class="bar" style="height:'.$height.'px; margin-top: ' . $topMargin . 'px;">' . "{$row['cnt']}({$dataQty['data'][$key]['cnt']})" . '</li>';
						
						if($key){
							$str2 .= '<li class="label">' . date('M-Y',strtotime($row['dt'])) . '</li>';
						}
						else{
							$str2 .= '<li class="label clearboth">' . date('M-Y',strtotime($row['dt'])) . '</li>';
						}
					}
				}
				else {
					$str1 .= '<h3 class="first">' . $this->__("No Activity found"). '</h3>';
				}
		$str = $str . $str1 . $str2;
		$str .= '</ul>
		<div class="clearboth"></div>
		</div>';
		
		echo $str;
	}
	public function StoreOverView($limit=5){

		$OrdersToday = App::Model('Order')->find("orderdate='" . date('Y-m-d') . "'",null,'count(*) as cnt');		
		$dateBefore3Month = date('Y-m-d',(time()-(60*60*24*90)));
		$OrdersLast3Month = App::Model('Order')->find("orderdate BETWEEN '{$dateBefore3Month}' AND '" . date('Y-m-d') . "'",null,'count(*) as cnt');		
		$OrdersPending = App::Model('Order')->find("paymentstatus='Pending'",null,'count(*) as cnt');		
		$OrdersCritical = App::InformationSet('Product')->find("(qty-criticalqty) < 0",null,'count(*) as cnt');		
		$ProductTotal = App::InformationSet('Product')->find("status='Active'",null,'count(*) as cnt');		
		$ItemSold = App::Model('Item')->find(null,null,'count(*) as cnt');	
		$Discountcoupon = App::InformationSet('Discountcoupon')->find("status='Redeemed'",null,'count(*) as cnt');
		
		$DataGrid = App::Module('DataGrid')
			->Clear()
			->setDisplay('FormListing')
			->addRow($OrdersToday['cnt'],"Orders Placed Today")
			->addRow($OrdersLast3Month['cnt'],"Orders Placed in last 3 months")
			->addRow($OrdersPending['cnt'],"Total Pending Orders")
			->addRow($OrdersCritical['cnt'],"Critical Products")
			->addRow($ProductTotal['cnt'],"Total Products in Store")
			->addRow($ItemSold['cnt'],"Total Items sold")
			->addRow($Discountcoupon['cnt'],"Total Coupon Redeemed")
			->Render();
	}

	public function latestProducts($limit=5){
		
		$Products = App::InformationSet('Product')->findAll("1 ORDER BY id DESC LIMIT 0, {$limit}");
		
		if(!empty($Products['data'])){
			$DataGrid = App::Module('DataGrid')->Clear();
			foreach($Products['data'] as $row){
				$DataGrid->addRow(
					$row['id'],
					App::Html()->imgTag(App::Config()->fileManagerUrl( DS . $row['imagethumb']),null,array('height'=>'35')),
					$row['title'],
					App::CategorySet()->idToName($row['category'],null,'Yes'),
					$row['status'],
					App::Html()->linkTag(App::Config()->baseUrl("/managestore/orders/view/{$row['id']}"),'View')
				);
			}
			$DataGrid
				->setHeader(array('ID','DATE','DELIVERY','STATUS','TOTAL','#'))
				->Render();
		}
	}	
	
	public function RecentOrders($limit=5){
		
		$Orders = App::Model('Order')->findAll("1 ORDER BY id DESC LIMIT 0, {$limit}");
		
		if(!empty($Orders['data'])){
			$DataGrid = App::Module('DataGrid')->Clear();
			foreach($Orders['data'] as $row){
				$DataGrid->addRow(
					$row['id'],
					App::Helper('Date')->DateFormated($row['orderdate']),
					$row['deliverystatus'],
					$row['paymentstatus'],
					number_format($row['totalcost'],2),
					App::Html()->linkTag(App::Config()->baseUrl("/managestore/orders/view/{$row['id']}"),'View')
				);
			}
			$DataGrid
				->setHeader(array('ID','DATE','DELIVERY','STATUS','TOTAL','#'))
				->Render();
		}
	}	
	
	public function RecentReviews($limit=5){		
		$Comments = App::Model('StoreComment')->findAll("1 ORDER BY id DESC LIMIT 0, {$limit}");
		if(!empty($Comments['data'])){
			$DataGrid = App::Module('DataGrid')->Clear();
			foreach($Comments['data'] as $row){
				$DataGrid->addRow(
					substr($row['comment'],0,15) . ' <strong>on</strong> ' .
					App::InformationSet('product')->idToName($row['productid'],'title','Yes'),
					App::Helper('Date')->DateFormated($row['dated']),
					$row['status'],
					App::Html()->linkTag(App::Config()->baseUrl("/managestore/comment/update/{$row['id']}"),'Edit')
				);
			}
			$DataGrid
				->setHeader(array('COMMENT','Status','DATE','#'))
				->Render();
		}
	}
}