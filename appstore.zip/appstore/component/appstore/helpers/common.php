<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP 
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_Common extends appRain_Base_Objects
{
	public $flag;
    public $selectedElement = '';
    public function getProductFeatureTable($product=null,$isHtml=false)
    {
        $product = is_array($product) ? $product : App::InformationSet('product')->findById($product);
		if(empty($product['features'])){
			return '';
		}
		
		$Attributes = explode("\n",$product['features']);
		if(empty($Attributes)){
			return ;
		}
		if($isHtml){
			$str = '<ul class="attribute-table">';
			foreach($Attributes as $Attribute){
				$row = explode("=",$Attribute);
				$row[0] = isset($row[0]) ? $row[0] : '';
				$row[1] = isset($row[1]) ? $row[1] : '';
				if(!empty($row[0])){
				$str .= '<li>';
					$str .= "<label>{$row[0]}</label>";
					$str .= "<span>{$row[1]}</span>";
				$str .= "</li>";
				}
			}
			return $str .= '</ul>';
			
		}
		else{
			$List = array();
			foreach($Attributes as $Attribute){
				$row = explode("=",$Attribute);
				$List[] = array("title"=>$row[0],"val"=>$row[1]);
			}
			return $List;
		}
    }
	
	public function getReletedProduct($skipid=null,$selected=null){
		$List = App::InformationSet('product')->findAll("1 ORDER BY id DESC");
		$Str = '';
		foreach($List['data'] as $row){
			if($row['id'] != $skipid){
				$Str .= '<div class="field">';
				$Str .= App::Html()->imgTag(App::Config()->filemanagerUrl("/{$row['imagethumb']}"),null,array("width"=>"30"));
				$Str .= App::Html()->checkboxTag("data[Product][relatedproduct][]",array($row['id']=>$row['title']),$selected);
				$Str .= '</div>';
			}
		}
		
		if(empty($Str)){
			$Str = '<h3 class="first warning">No Releted product found</h3>';
		}
		
		return $Str;
	}
	
	public function getAttributeGroupById($id=null){
		$attGroup = App::InformationSet('attributegroup')->findById($id);
		if(empty($attGroup)){
			return ;
		}
		
		if($attGroup['object'] != ''){
			$attGroup['object'] = unserialize($attGroup['object']);
		}
		return $attGroup;
	}
	
	public function getRelatedProduct($Product=null){
		if(!is_array($Product)){
			$Product = App::InformationSet('product')->findById($Product);
		}
		
		if(empty($Product['relatedproduct'])){
			return ;
		}
		
		$str = ' ';
		foreach(explode(',',$Product['relatedproduct'])  as $key=>$pid){
			$Prod = App::InformationSet('product')->findById($pid);
			$str .= '<div class="col-md-2 align-center">';
			$str .= App::Html()->linkTag(App::Config()->baseUrl("/item-detail/{$pid}/" . App::Helper('Utility')->text2Normalize($Prod['title']) ),App::Html()->imgTag(App::Config()->filemanagerUrl("/{$Prod['imagethumb']}"),null,array("height"=>"100","class"=>"img-thumbnail")));
			$str .= '<h4>';
			$str .= $Prod['title']; // App::Html()->linkTag(App::Config()->baseUrl("/item-detail/{$pid}/" . App::Helper('Utility')->text2Normalize($Prod['title']) ),);
			$str .= '</h4>';
			$str .= '</div>';
		}
		$str .= '';
		
		return $str;
	}
	
	public function getAttributeHtmlBox($id,$Product=null){

		if(!is_array($Product)){
			$Product = App::InformationSet('product')->findById($Product);
		}
		
		$attributevalue = isset($Product['attributevalue']) ? unserialize($Product['attributevalue']) : array();
		
		$Group = $this->getAttributeGroupById($id);
		$str ='';	
		if(!empty($Group['object'])){
			$inputTags = array('TextBox'=>'inputTag','RadioButton'=>'radioTag','DropDown'=>'selectTag','CheckBox'=>'checkboxTag','colorInput'=>'colorInput','image'=>'fileTag','TextArea'=>'TextareaTag');
			$ValidationRule = array('Email'=>'check_email','Empty'=>'check_notempty');
			foreach($Group['object'] as $key=>$row){
				if(isset($row['key'])){
				
					$defaultvalue = isset($attributevalue[$row['key']]['value']) ? $attributevalue[$row['key']]['value'] : $row['defaultvalue'];
					$defaultQty = isset($attributevalue[$row['key']]['qty']) ? $attributevalue[$row['key']]['qty'] : '';

					$htmlTag = $inputTags[$row['type']];
					$validationrule = isset($ValidationRule[$row['validation']]) ? $ValidationRule[$row['validation']] : '';
					$t = '';
					if(in_array($htmlTag,array('radioTag','selectTag'))){					
						$valueArr = array();
						foreach(explode(',',$row['optvalues']) as $v){
							$valueArr[$v]=$v;
						}
						$t .= 'Qty: <input name=' . "data[Product][prod_attr_qty_{$key}]" . ' value="' . $defaultQty . '" type="text" size="3" />';
						$t .= App::Html()->$htmlTag("data[Product][prod_attr_{$key}]",$valueArr,$defaultvalue,array("class"=>$validationrule));
						
					}
					elseif(in_array($htmlTag,array('checkboxTag'))){					
						$valueArr = array();
						foreach(explode(',',$row['optvalues']) as $k => $v){
						    $defaultvalue = is_array($defaultvalue) ? $defaultvalue : array($defaultvalue); 
							$dfl = isset($defaultQty[$k]) ? $defaultQty[$k] : '';
							$checked = '';
							
							if(in_array($v,$defaultvalue)){							
								$checked = ' checked="checked" ';
							}							
							$t .= 'Qty: <input type="text" name="' . "data[Product][prod_attr_qty_{$key}][{$k}]" . '" value="' . $dfl  . '" size="3" />';
							$t .= '<input type="checkbox" ' . $checked .  ' name="' . "data[Product][prod_attr_{$key}][{$k}]" . '" value="' . $v . '" />';
							$t .= "<lable >{$v}</label><br />";
						}
					}
					elseif(in_array($htmlTag,array('colorInput'))){					
						$valueArr = array();
						foreach(explode(',',$row['optvalues']) as $k=>$v){		
							$defaultvalue = is_array($defaultvalue) ? $defaultvalue : array($defaultvalue); 
							$dfl = isset($defaultQty[$k]) ? $defaultQty[$k] : '';
							$t .= 'Qty: <input name="' . "data[Product][prod_attr_qty_{$key}][]" . '" type="text" value="' . $dfl  . '" size="3" />';						
							$checked = '';
							if(in_array($v,$defaultvalue)){							
								$checked = ' checked="checked" ';
							}
							$t .= '<input type="checkbox" ' . $checked .  ' name="' . "data[Product][prod_attr_{$key}][]" . '" value="' . $v . '"  id="chk231360084509" />';
							$t .= "<strong style=\"background-color:{$v};color:{$v};padding:0 2px;margin:2px;border:1px solid\">{$v}</strong><br />";
						}
					}
					else if(in_array(strtolower($row['type']),array('fileTag','image'))){
						if($defaultvalue != ''){
							$t = '<div class="imagespan">
								<img src="' . App::Config()->filemanagerurl(DS . $defaultvalue) . '" height="40" />
								<img class="delete_image" style="cursor:pointer" longdesc="{\'action\':\'attributefile\',\'pid\':\'' . $Product['id'] .  '\',\'key\':\'' . $row['key'] . '\'}" src="' . App::Config()->baseUrl('/images/admin/remove.gif') . '">
							</div>';
						}
						$t .= 'Qty: <input name="' . "data[Product][prod_attr_qty_{$key}]" . '" type="text"  value="' . $defaultQty . '"  size="3" /> ';
						$t .= App::Html()->$htmlTag("data[Product][prod_attr_{$key}]",$defaultvalue,array('class'=> $validationrule));
					}
					else {
						$t .= 'Qty: <input name="' . "data[Product][prod_attr_qty_{$key}]" . '" type="text"  value="' . $defaultQty . '"  size="3" /> ';					
						$t .= App::Html()->$htmlTag("data[Product][prod_attr_{$key}]",$defaultvalue,array('class'=> $validationrule));
					}
							
					$str .= '<div class="field">
						<div class="label">
							<label for="name">' . $row['title'] . '<label>
						</div>
						<div class="input">
							' . $t . '	
						</div>
					</div>';
				}
			}
		}
		else {
			$str = '<h3 class="warning">' . $this->__("Attribute field not defined") . '</h3>';
		}
		
		return $str ;		
	}
	
	public function updateAttributeObject($data=null,$action='save'){
	
		switch($action){
			case 'remove':
				$Group = $this->getAttributeGroupById($this->getId());
				if(!empty($Group['object'])){
					$objectArr = array();
					foreach($Group['object'] as $key=>$row){
						if($key!=$data){
							$objectArr[]=$row; 
						}
					}
				}
				$this->SaveAttributeObject($objectArr);
				break;
			case 'editattribute':
				$Group = $this->getAttributeGroupById($this->getId());				

				if(!empty($Group['object'])){
					foreach($Group['object'] as $key=>$row){
						if($key==$this->getSequence()){
							$data['key'] = (!isset($row['key']) OR empty($row['key'])) ? $this->getAttributeKey(): $row['key'];
							$Group['object'][$key]=$data; 							
						}
					}
				}
				$this->SaveAttributeObject($Group['object']);
		}
	}
	
	public function SaveAttributeObject($object=null){
		if(is_array($object)){
			$object = serialize($object);
		}
		
		App::InformationSet('attributegroup')
			->setId($this->getId())
			->setObject($object)
			->Save();
	}
	
	public function getProductValue($Product=null,$field=null,$default=''){
		if(!isset($Product)){
			return '';
		}
		
		return isset($Product[$field]) ? $Product[$field] : $default;
	}
	
	public function getProductList(){
		$cnd = '1';
		if(isset($_GET['src'])){
			$src = $_GET['src'];
			$cnd = "title LIKE '%{$src}%' OR description LIKE '%{$src}%'";
			
			$category = App::CategorySet('product-cat')->findAll("title LIKE '%{$src}%'");
			if(!empty($category['data'])){
				$str = implode(',',App::Utility()->get1DArr($category['data'],'id','id'));
				$cnd .= "OR category in (" . $str . ")";
			}
			
		}
		return App::InformationSet('product')->paging("{$cnd} ORDER BY id DESC",15);
	}
	
	public function hasUpdateAccess($action){
		return in_array($action,array('add','update'));
	}
	
	public function productManagerInsideButton($action='view',$anchor='',$id=null){
		if($this->hasUpdateAccess($action)){
			return '<input type="submit" name="Anchor[' . $anchor . ']" value="Submit" />' . 
			' <input type="button" onclick="javascript:history.go(-1);" name="Anchor[' . $anchor . ']" value="<< Back" />';
		}
		else {
			return '<input type="button" onclick="javascript:history.go(-1);" name="Anchor[' . $anchor . ']" value="<< Back" />' .
			' <input type="button" onclick="window.location = siteInfo.baseUrl + \'/managestore/products/update/' . $id . "#{$anchor}" . '\';" name="Anchor[Edit]" value="Edit" />';
		}
	}	
	
	public function attributeInHtml($Product){
		if(!is_array($Product)){
			$Product = App::InformationSet('product')->findById($Product);
		}
		
		$AllOtherProducts = App::InformationSet('product')->findAllByAttributegroup($Product['attributegroup']);
		$valueList=array();
		foreach($AllOtherProducts['data'] as $OProduct){
			if($OProduct['attributevalue'] != ''){
				$OAttributevalues = unserialize($OProduct['attributevalue']);
				foreach($OAttributevalues as $key=>$OAttributevalue){
					$valueList[$key][] = $OAttributevalue['value'];
				}
			}
		}		

		$Group = $this->getAttributeGroupById($Product['attributegroup']);
		$attributevalue = unserialize($Product['attributevalue']);
		$str = '';
		if(!empty($Group['object'])){
			foreach($Group['object'] as $obj){
				if(isset($valueList[$obj['key']]) && isset($attributevalue[$obj['key']])){
					$value = is_array($attributevalue[$obj['key']]['value']) ? current($attributevalue[$obj['key']]['value']) : $attributevalue[$obj['key']]['value'];
					$VList = array();
					foreach($valueList[$obj['key']] as $key=>$val){
						if(is_array($val)){
							$VList = array_merge($VList,$val);
						}
						else {
							$VList[]=$val;
						}						
					}

					$dataarr=array();
					foreach($VList as $key=>$VL){
						$dataarr[$VL] = $VL;
					}
									
					$str .= '<div class="col-md-2 attributelistbox-title">';
					$str .= "{$obj['title']}";	
					$str .= "</div>";
					$str .= '<div class="col-md-10 attributelistbox">' ;
					$str .= $this->createAttributeElements($obj,$dataarr,$value);//App::Html()->radioTag("data[Attribute][{$obj['key']}]",$dataarr,$value);	
					$str .= "</div>";
				}
			}
		}
		return $str;
		
		
	}
	
	private function createAttributeElements($obj=null,$dataarr=array(),$default=null){
		$str = '';
		$ii = 1;
		foreach($dataarr as $key=>$name){
			$Checked = '';
			if(empty($default) || ($default == $name)){
				$Checked = 'checkedattribute';
				$str .= '<input id="hiddenbox_' . $obj['key'] . '" name="' . "data[Attribute][{$obj['key']}]" . '" type="hidden" value="' . $name . '" />';
			}			
			if($obj['type'] == 'colorInput'){
				$str .= '<label data="' .  "{'value':'{$name}',key:'{$obj['key']}'}"  . '" style="background-color:' . $name . '" for="' . $ii. $obj['key'] . '" class="' . $Checked . ' attributelblblock colorbox" >&nbsp;</label>';
			}
			else if($obj['type'] == 'image'){
				$str .= '<label data="' .  "{'value':'{$name}',key:'{$obj['key']}'}"  . '" style="background-color:' . $name . '" for="' . $ii. $obj['key'] . '" class="' . $Checked . ' attributelblblock" >' . App::Html()->imgTag(App::Config()->filemanagerUrl("/{$name}"),null,array('width'=>"20",'height'=>"20")) . '</label>';
			}			
			else {
				$str .= '<label data="' .  "{'value':'{$name}',key:'{$obj['key']}'}"  . '" for="' . $ii. $obj['key'] . '" class="' . $Checked . ' attributelblblock" >' . $name . '</label>';
			}
			$ii++;
		}
		return $str;
	}
	
	public function getAttributeKey(){
		return rand(100,999) .  time();
	}
	
	public function getAttributeSuggession($key=null,$attributes=null,$PId=null){
		$Product = App::InformationSet('product')->findById($PId);
		$productlist = App::InformationSet('product')->findAllByAttributegroup($Product['attributegroup']);
		$Group = $this->getAttributeGroupById($Product['attributegroup']);
		$referedvalue = $attributes[$key];
		$strfinal='';
		$cellwidth = '430';
		$width = 0;
		$links = '';
		$page = 0;
		$this->selectedElement = '';
		foreach($productlist['data'] as $product){
			$attributevalue = unserialize($product['attributevalue']);
			
			$str = '<div style="width:' . $cellwidth . 'px;float:left ">';
			$str .= '<div class="grid_2">' .App::Html()->linkTag(App::Config()->baseUrl("/item-detail/{$product['id']}/" . App::Utility()->text2Normalize($product['title'])), App::Helper('Html')->imgTag($product['imagethumb'],array('mode'=>'imagemanager'),array('class'=>'box','height'=>'30'))) . '</div>';
			$str .= '<div class="grid_6">' . '<div class="grid_2"><b>' . App::Html()->linkTag(App::Config()->baseUrl("/item-detail/{$product['id']}/" . App::Utility()->text2Normalize($product['title'])),$product['title']). '</b></div><div class="clear"></div>';
			$str .= App::Component('Appstore')->Helper('Common')->getPricebox($product,false);
			$str .=  '</div><div class="clear"></div>';
			$str .= '<ul class="attr-suggessionbox">';
			$this->flag = false;
			foreach($Group['object'] as $obj){
				if(isset($attributevalue[$obj['key']])){
					$row = $attributevalue[$obj['key']];
					$str .= '<li><span>';
					$str .= ($row['title']);
					$str .= '</span>';
					if(is_array($row['value'])){
						foreach($row['value'] as $key=>$value){
							if($row['qty'][$key] === "" || (int) $row['qty'][$key] > 0){
								$str .= $this->createBox($value,$referedvalue,$obj);
							}
						}
					}
					else {
						
						$str .= $this->createBox($row['value'],$referedvalue,$obj);
					}					
				}
			}			
			$str .= '</ul></div>';
			if($this->flag)
			{
				$links .= App::Html()->linkTag(null,($page+1),array("class"=>"attrsuspagelink","onclick"=>"jQuery('#suggessionbodyscroller').animate({scrollLeft: {$width}}, 'slow');"));
				$width += $cellwidth;
				$strfinal .= $str;
				$page++;
			}
		}
		if($strfinal !=''){
			$pagingstr = (($page > 1) ?  '<div class="attrsugpaging">' .  $links . '</div>': ''); 
			$strfinal = 
			'
			<div id="suggessionbody">
			<h3>Suggested "' . $this->selectedElement . '" Products</h3> 
				<div id="suggessionbodyscroller">
					<div id="attrsuspagescroller" style="width:' . $width . 'px">'
						. $strfinal	. 
					'</div>
				</div>' 
				. $pagingstr 
				. App::Html()->linkTag(null,null,array('id'=>'closesugbox','class'=>'fancybox-item fancybox-close','onclick'=>"jQuery('#suggession').hide(1000);"))
			.'</div>';
			
			return $strfinal;
		}
	}
	
	public function createBox($value,$checkwith=null,$obj=null){
		$style ='';
		$class = '';
		$captureSelected = false;
		if($value==$checkwith){
			$this->flag = true;		
			$captureSelected = true;	
			$style = 'border:2px solid red;';	
		}
		
		$innHTML = $value;
		if($obj['type'] == 'colorInput'){
			$innHTML = '<div class="colorbox" style="' . "background-color:{$value};" . '">&nbsp &nbsp;</div> ';
		}
		elseif($obj['type'] == 'image'){		
			$innHTML = App::Html()->imgTag(App::Config()->filemanagerUrl(DS . $value),null,array("width"=>"30"));
		}
		
		$str = '<label   style="' . $style . '" class="' . $class . '">' . $innHTML . '</label>';
		if($captureSelected){
			$this->selectedElement = $str;
		}		
		
		return $str;
	}

	public function getPrice($Product=null,$showOld=false){
		if(!is_array($Product)){
			$Product = App::InformationSet('product')->findById($Product);
		}	

		if(!$showOld){
			return App::Helper('Config')->setting('currency','$') . App::Component('appStore')->Helper('data')->currencyFormate($Product['price']);
		}
		else {
			if($Product['oldprice'] !=''){
				return App::Helper('Config')->setting('currency','$') . App::Component('appStore')->Helper('data')->currencyFormate($Product['oldprice']);
			}
		}
	}
	
	public function getPricebox($Product=null,$showOld=true){
		if(!is_array($Product)){
			$Product = App::InformationSet('product')->findById($Product);
		}	
		$str = '';		
		$title = 'Price';
		if($Product['oldprice']!='' && $Product['oldprice'] > $Product['price'] && $showOld){
			$title = 'Discount Price';
			$str .= '<div class="grid_2 line-through">Price</div><div class="grid_4 line-through">' ;
			$str .= App::Helper('Config')->setting('currency','$') . App::Component('appStore')->Helper('data')->currencyFormate($Product['oldprice']);
			$str .= '</div><br class="clear" />';
		}
		$str .= '<div class="grid_2 hilight-color bold">' . "{$title}:</div>" . '<div class="grid_4 bold">' ;
		$str .= App::Helper('Config')->setting('currency','$') . App::Component('appStore')->Helper('data')->currencyFormate($Product['price']);
		$str .= '</div><br class="clear" />';

		return $str;
	}
	
    public function getItemAttributes($Item=null,$returnType='html'){
		if(!is_array($Item)){
			$Item = App::InformationSet('Item')->findById($Item);
		}	
		
		$attributes = array();
		if(!empty($Item['attributes'])){
			$attributes = is_string($Item['attributes']) ? unserialize($Item['attributes']) : $Item['attributes'];
		}
		$str = '';
		if(!empty($attributes)){
			$str = '<table width="100%" class="product-attribute-table">';
			foreach($attributes as $key => $val){
				$val['title'] = ucfirst($val['title']);
				$str .= "<tr>";
				if(is_array($val['value'])){
					$val['value'] = implode(',',$val['value']);
				}
				if(substr($val['value'],0,1) =='#' and  strlen($val['value']) == 7){
					$str .= "<th width=\"100\" align=\"left\">{$val['title']}</th><td><div class=\"img-circle\" style=\"background-color:{$val['value']};width:25px;height:25px\">&nbsp;</div></td>";
				}
				elseif(App::Utility()->is_image($val['value'])){
					$str .= "<th width=\"100\" align=\"left\">{$val['title']}</th><td>" . App::Html()->imgTag(App::Config()->fileManagerUrl("/{$val['value']}"),null,array("width"=>"40")) . "<br />{$val['value']}</td>";
				}
				else {
					$str .= "<th width=\"100\" align=\"left\">{$val['title']}</th><td>{$val['value']}</td>";
				}
				
				$str .= "</tr>";
			}
			$str .= '</table>';
		}
		return $str;
	}
    
	/*public function getItemAttributes($Item=null,$returnType='html'){
		if(!is_array($Item)){
			$Item = App::InformationSet('Item')->findById($Item);
		}	
		
		$attributes = array();
		if(!empty($Item['attributes'])){
			$attributes = is_string($Item['attributes']) ? unserialize($Item['attributes']) : $Item['attributes'];
		}
		$str = '';
		if(!empty($attributes)){
			$str = '<table width="100%">';
			foreach($attributes as $key => $val){
				$val['title'] = ucfirst($val['title']);
				$str .= "<tr>";
				if(is_array($val['value'])){
					$val['value'] = implode(',',$val['value']);
				}
				if(substr($val['value'],0,1) =='#' and  strlen($val['value']) == 7){
					$str .= "<th width=\"100\" align=\"left\">{$val['title']}</th><td style=\"background-color:{$val['value']}\">&nbsp;</td>";
				}
				elseif(App::Utility()->is_image($val['value'])){
					$str .= "<th width=\"100\" align=\"left\">{$val['title']}</th><td>" . App::Html()->imgTag(App::Config()->fileManagerUrl("/{$val['value']}"),null,array("width"=>"40")) . "<br />{$val['value']}</td>";
				}
				else {
					$str .= "<th width=\"100\" align=\"left\">{$val['title']}</th><td>{$val['value']}</td>";
				}
				
				$str .= "</tr>";
			}
			$str .= '</table>';
		}
		return $str;
	}*/
	
	public function productPresentationBox($Product=null){
		if(!is_array($Product)){
			$Product = App::InformationSet('product')->findById($Product);
		}	
		$type = $Product['slidetype'];
		if($type == 'Zoom'){
			$imagelist = explode(',',$Product['imagelist']);
			$str = '<script type="text/javascript">
				jQuery(document).ready(function () {
					jQuery("#zoom").elevateZoom({gallery:"gal1", cursor: "pointer",easing : true,zoomWindowWidth:460,zoomWindowOffetx:10}); 
					jQuery("#zoom").bind("click", function(e) {  
						var ez =   jQuery("#zoom").data("elevateZoom");	
						jQuery.fancybox(ez.getGalleryList());
						return false;
					}); 
				});
			</script>';
			if(!empty($Product['imagelist']) && isset($imagelist[1]) && $imagelist[2]){
				
				$str .= '<img class="product-detail img-thumbnail" id="zoom" src="' . App::Config()->baseUrl("/uploads/filemanager/{$imagelist[1]}") .'" data-zoom-image="' . App::Config()->baseUrl("/uploads/filemanager/{$imagelist[2]}") .'"/>';
				if(count($imagelist)>3){
					$str .= '<div id="gal1" class="center">';
					for($ii=0; $ii < count($imagelist); $ii += 3){
						if(isset($imagelist[$ii+2])){
							$str .= '<a href="#" data-image="' . App::Config()->baseUrl("/uploads/filemanager/" . $imagelist[$ii+1]). '" data-zoom-image="' . App::Config()->baseUrl("/uploads/filemanager/" . $imagelist[$ii+2]) .'">';
							$str .= '<img width="33%" class="img-thumbnail" src="'. App::Config()->baseUrl("/uploads/filemanager/" . $imagelist[$ii]) .'" />';
							$str .= '</a>';
						}
					}
					$str .= '</div>';
				}
			}
		}
		elseif($type == 'NewWindow'){
			$str = '<a href="' . App::Config()->baseUrl("/uploads/filemanager/{$Product['imagelist']}").'" target="_blank">' .
				'<img class="product-detail" width="450" id="NewWindowImage" src="' . App::Config()->baseUrl("/uploads/filemanager/{$Product['image']}") . '"/>' .
			'</a>';
		}
		else {
			$str = 	'<img class="product-detail" width="270" id="NewWindowImage" src="' . App::Config()->baseUrl("/uploads/filemanager/{$Product['image']}") . '"/>' ;
		}
		return $str;
	}
	public function openGriedCSSClass($cnt=0,$key=0){     
            $class ='';
            if(($cnt-4) < $key){
                if ($key%3 != 0) {
                    $class='pborderbl';
                }
            }
            elseif ($key%3 == 0) {
                $class='pborderb';
            }
            else{
                $class='pborderlb';
            }  
            
            return $class;
        }
	public function quickstat($Product=null,$rateonly=null){
		
			if(App::Config()->setting('store_disable_product_qinfo','No') == 'Yes'){
				return '';
			}
		
			if(!is_array($Product)){
				$Product = App::InformationSet('product')->findById($Product);
			}
			
			$Reviewstr = '';
			if(App::Config()->setting('store_disable_customer_review','No') != 'Yes'){
				$Comments = App::Model('StoreComment')->findAll("productid={$Product['id']} and status='Active'");		
				$totalreview = count($Comments['data']);	
				$pionts = 0;
				$emails = array();
				if(!empty($Comments['data'])){				
					foreach($Comments['data'] as $comment){
						$emails[$comment['email']] = $comment['name'];
						$pionts += $comment['rate'];
					}
				}
				$totalrate  = ( $totalreview > 0 ) ? round($pionts/$totalreview,2) : 0;
				$totalReviewByCustomer = count($emails);
                
                $Reviewstr .= '';
                for($i=1;$i<=$totalrate;$i++){
                    $Reviewstr .= "<span class=\"glyphicon glyphicon-star\"></span>";
                }
                for($i=1;$i<=(5-$totalrate);$i++){
                    $Reviewstr .= "<span class=\"glyphicon glyphicon-star-empty\"></span>";
                }
                if($rateonly){
                    return $Reviewstr;
                }
                $Reviewstr .= ' Rate | ';
				
				$Reviewstr .= "<span class=\"fa fa-comment\"></span> {$totalreview} Comments";
			}
			
			$sixMonthBack = date('Y-m-d',(time()-(60*60*24*30*6)));

			$items = App::Model('Item')->findALl("productid={$Product['id']} and dated > '{$sixMonthBack} 00:00:00'");
			
			$tQty = 0;
			$totalOrders = 0;
			foreach($items['data'] as $item){
				$order = App::Model('Order')->findById($item['orderid']);
				if($order['paymentstatus'] == Component_Appstore_Helpers_Data::STATUS_PAID){
					$tQty = $item['qty'];
					$totalOrders++;
				}
			}
			
			return  $Reviewstr . " | Past 6 months: {$totalOrders} orders ({$tQty} pieces)"; 
        }
		
		public function RenderWidget($Position=null){
			$Widget = App::InformationSet('widget')->findAll("position='{$Position}' ORDER BY sortorder ASC");
			
			if(!empty($Widget['data'])){
				foreach($Widget['data'] as $row){
					$url = null;
					if($row['url'] != ''){
						$url = App::Utility()->codeFormated($row['url']);
					}
					echo '<div class="storewidteg">';
						if( $row['title'] !=''){
							if(isset($url)){
								echo "<h3>". App::Html()->LinkTag($url,$row['title']). "</h3>";
							}
							else{
								echo "<h3>{$row['title']}</h3>";
							}
						}
						echo '<div class="storewidteg-body">';	
							if($row['image'] != ''){
								$img =  App::Html()->imgTag(App::Config()->filemanagerurl( DS . $row['image']),null,array("width"=>"210"));
								if(isset($url)){
									echo App::Html()->LinkTag($url,$img);
								}
								else {
									echo $img;
								}
								
							}
							echo "{$row['description']}";
						echo '</div>';	
					echo '</div>';	
				}
			}
		}
}