<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_Invoice extends Component_AppStore_Helpers_PDF_FPDF
{
    public $b = 0;
	public $fontFamily = 'Helvetica';
	
    public function CreateInvoice($orderid=NULL,$status=Component_Appstore_Helpers_Data::STATUS_PAID){
		return $this->ItemTable($orderid);
	}
	
	private function AddNewPage($isInner = false){
	
		$this->SetTopMargin(0);
		$this->SetLeftMargin(0);
		$this->AddPage("p");		
		$this->SetTextColor(255, 255, 255);	
		$this->SetFillColor(79,198,221);
		$this->SetFont($this->fontFamily,'B',20); 
		if($isInner){
			$this->Cell(283,30 ,' ' . (App::Config()->setting('site_title') . ' Invoice') ,$this->b,1,'L',1); 
		}
		else{
			$this->Cell(283,50 ,' ' . (App::Config()->setting('site_title') . ' Invoice') ,$this->b,1,'L',1); 
		}
		
		$this->SetTextColor(0, 0, 0);	
		$this->Ln(15);
		$this->SetTopMargin(10);
		$this->SetLeftMargin(10);	
	}
	
	private function ItemTable($orderid)	
	{
        if(!isset($orderid)){
            $orderid = $this->getOrderId();
        }		

		$this->AddNewPage();

		$this->SetFont($this->fontFamily,null,12); 

		$this->Cell(20,15 ,"Dated",$this->b); 
		$this->Cell(100,15 ,": " .  App::Helper('Date')->dateFormated(time(),'long') ,$this->b,1);
 		$this->Cell(20,6 ,"Cell",$this->b); 
		$this->Cell(100,6 ,": " . App::Config()->Setting('appstoresettings_contact_phone','123456789') ,$this->b,1); 
		$this->Cell(20,6 ,"Email" ); 
		$this->Cell(100,6,": " . App::Config()->Setting('admin_email','info@example.com') ,$this->b,1); 
		$this->Ln(40);		
		
		$this->SetFont($this->fontFamily,'b',14); 
		$this->Cell(130,15 ,App::Config()->Setting('appstoresettings_contact_address_1_title','Address 1'),$this->b); 
		$this->Cell(130,15 ,App::Config()->Setting('appstoresettings_contact_address_2_title','Address 2'),$this->b,1); 
		
		$address1 = explode("\n",App::Config()->Setting('appstoresettings_contact_address_1'));		
		$address2 = explode("\n",App::Config()->Setting('appstoresettings_contact_address_2'));		
		$count = (count($address1) > count($address2)) ? count($address1) : count($address2);
		
		$this->SetFont($this->fontFamily,null,12); 
		if($count>0){
			for($i=0; $i<$count; $i++){
				$address1[$i] = isset($address1[$i]) ? $address1[$i] : '';
				$this->Cell(130,6 ,$address1[$i] ,$this->b,0); 
				
				$address2[$i] = isset($address2[$i]) ? $address2[$i] : '';
				$this->Cell(130,6 ,$address2[$i] ,$this->b,1); 				
			}
		}
					
        $currency = App::Helper('Config')->siteInfo('currency');
		$Order = App::Model('Order')->findById($orderid);
		$billingaddress = unserialize($Order['billingaddress']);		
		$shippingaddress = ($Order['shippingaddress'] !='') ? unserialize($Order['shippingaddress']) : $billingaddress;

        $items = App::Model('Item')->findAllByOrderid($orderid);
		
		$this->AddNewPage(true);
		
		$this->SetFont($this->fontFamily,'b',14); 
		$this->Cell(130,15 ,"Billing Address",$this->b); 
		$this->Cell(130,15 ,"Shipping Address",$this->b,1); 
		
		$this->SetFont($this->fontFamily,'b',12); 
		$this->Cell(130,6 ,"{$billingaddress['fname']} {$billingaddress['fname']}" ,$this->b,0); 
		$this->Cell(130,6 ,"{$shippingaddress['fname']} {$shippingaddress['fname']}" ,$this->b,1); 
		$this->SetFont($this->fontFamily,null,12);
		
		$this->Cell(130,6 ,$billingaddress['address_line_1'],$this->b ); 
		$this->Cell(130,6 ,$shippingaddress['address_line_1'],$this->b,1 ); 
		
		$this->Cell(130,6 ,$billingaddress['address_line_2'],$this->b,0 ); 
		$this->Cell(130,6 ,$shippingaddress['address_line_2'],$this->b,1 ); 

		$this->Cell(130,6 ,$billingaddress['city'] . ', ' . $billingaddress['zipcode'],$this->b,0 ); 
		$this->Cell(130,6 ,$shippingaddress['city'] . ', ' . $shippingaddress['zipcode'],$this->b,1 ); 
		
		$this->Cell(130,6 ,$billingaddress['state'] . ', ' . $billingaddress['country'],$this->b,0 ); 
		$this->Cell(130,6 ,$shippingaddress['state'] . ', ' . $shippingaddress['country'],$this->b,1 ); 
		
		$this->Cell(130,6 ,$billingaddress['email'] ,$this->b,0); 
		$this->Cell(130,6 ,$shippingaddress['email'] ,$this->b,1); 
		
		$this->Cell(130,6 ,$billingaddress['phoneno'] ,$this->b,0); 
		$this->Cell(130,6 ,$shippingaddress['phoneno'] ,$this->b,1); 
		
		$this->Ln(15);	
		$this->SetFont($this->fontFamily,'b',14); 
		$this->Cell(130,15 ,"Invoice (Order Id: {$orderid})",$this->b,1); 
		$this->SetFont($this->fontFamily,'b',12); 
		$this->Cell(30,6 ,"Code" ,1,0,'C'); 
		$this->Cell(110,6 ,"Description",1,0,'L'); 
		$this->Cell(30,6 ,"Qty",1,0,'C'); 
		$this->Cell(40,6 ,"Unit Price",1,0,'C'); 
		$this->Cell(50,6 ,"Total Amount",1,1,'R'); 
		$this->SetFont($this->fontFamily,null,12); 	
		
		$gandtotal = 0;
        $tqty = 0;
        $DataGrid = App::Module('DataGrid');
        foreach($items['data'] as $val){
            $pid = $val['productid'];
            $qty = $val['qty'];

            $tmp = Array();
            $product = App::InformationSet('product')->findById($pid);
			
			$subtotal = ($qty * $product['price']);
			$gandtotal += $subtotal;
			$this->SetFont('Arial');	
			$this->setFontSize('12');
			$this->Cell(30,10 ,$product['id'] ,1,0,'C'); 			
			$downloadlinks = null;
			$downlaodtext = '';
			if(strtolower($product['type']) == 'virtual'){
				$downlaodtext = ' (Download)';
				$downloadlinks = App::Config()->baseUrl("/appstore/download/" . base64_encode("{$orderid}O{$product['id']}"));
			}			
			if(file_exists(App::Helper('Config')->basedir("/uploads/filemanager/{$product['imagethumb']}"))){
				$this->Image(App::Helper('Config')->basedir("/uploads/filemanager/{$product['imagethumb']}"),$this->getX(),$this->getY(),10,10);	
				$this->Cell(10,10 ,"",1,0,'L'); 	
				$this->Cell(100,10 ,$product['title'] . $downlaodtext,1,0,'L',null,$downloadlinks); 
			}
			else {		
				$this->Cell(110,10 ,$product['title'] . $downlaodtext,1,0,'L',null,$downloadlinks); 
			}
			$this->Cell(30,10 ,$qty,1,0,'C'); 
			$this->Cell(40,10 ,$currency . App::Component('appStore')->Helper('Data')->currencyFormate($product['price']),1,0,'C'); 
			
			$this->Cell(50,10,$currency . App::Component('appStore')->Helper('Data')->currencyFormate($subtotal),1,1,'R'); 
					
        }
		
		$gandtotal -= $Order['discount'];
		$this->Cell(170,8 ,'',0,0,'C'); 
		$this->Cell(40,8 ,'Discount ',1,0,'R');
		$this->Cell(50,8 ,$currency . App::Component('appStore')->Helper('Data')->currencyFormate($Order['discount']),1,1,'R'); 
		$gandtotal += $Order['shippingcost'];
		
		$this->Cell(170,8 ,'',0,0,'C'); 
		$this->Cell(40,8 ,'Shipping Cost ',1,0,'R');
		$this->Cell(50,8 ,$currency . App::Component('appStore')->Helper('Data')->currencyFormate($Order['shippingcost']),1,1,'R'); 
		
		$this->Cell(170,8 ,'',0,0,'C'); 
		$this->SetTextColor(255, 255, 255);	
		$this->SetFillColor(0,0,0);
		$this->Cell(40,8 ,'Total Amount ',0,0,'R',1);

		$this->SetTextColor(0, 0, 0);	
		$this->SetFillColor(255,255,255);		
		$this->Cell(50,8 ,$currency . App::Component('appStore')->Helper('Data')->currencyFormate($gandtotal),1,1,'R'); 
		
		
		$path = $this->getFilePath($orderid);
		$this->Output($path);
	}
	
	public function getFilePath($orderid=null,$filenameOnly=false){
		$fileName = 'Invoice_' . $orderid . '.pdf';
		if($filenameOnly){
			return $fileName;
		} 
		else{
			$path = App::Component('Appstore')->Helper('Data')->getResourcePath(); #'virtualproduct'
			return $path . DS . $fileName;
		}
	}
	
	
	
	public function fileLink($orderId=null){
		$path = $this->getFilePath($orderId);
		$str = '';
		if(file_exists($path)){
			$str = App::Html()->LinkTag(App::Config()->baseUrl("/managestore/getinvoice/{$orderId}"),'Download Invoice');
		}
		else{
			$str = 'No Invoice found, ';
			$str .= App::Html()->LinkTag(App::Config()->baseUrl("/managestore/getinvoice/{$orderId}/create"),'click here');
			$str .=' to create manually';
		}
		
		return '<h3 class="first">' . $str . '</h3>';
	}
}