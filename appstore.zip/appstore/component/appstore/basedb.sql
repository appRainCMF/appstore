-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `dated` datetime NOT NULL,
  `title` varchar(200) NOT NULL,
  `unitprice` float NOT NULL,
  `totalprice` float NOT NULL,
  `shippingcost` float NOT NULL,
  `productdata` text NOT NULL,
  `attributes` text NOT NULL,
  `status` enum('Pending','Processing','Complete') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qty` int(11) NOT NULL,
  `totalcost` float NOT NULL,
  `shippingaddress` text NOT NULL,
  `billingaddress` text NOT NULL,
  `shippingcost` float NOT NULL,
  `discount` float NOT NULL,
  `discountid` text NOT NULL,
  `nextdaydelivery` enum('Yes','No') NOT NULL DEFAULT 'No',
  `orderdate` date NOT NULL,
  `paymenttype` varchar(50) NOT NULL,
  `paymentdata` text NOT NULL,
  `deliverystatus` enum('Processing','Pending','Complete') NOT NULL DEFAULT 'Pending',
  `paymentstatus` enum('Pending','Paid') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminref` int(11) NOT NULL,
  `entrydate` datetime NOT NULL DEFAULT '2012-12-29 15:01:06',
  `lastmodified` datetime NOT NULL,
  `title` varchar(150) NOT NULL,
  `category` int(11) NOT NULL,
  `imagethumb` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `shortdesc` text NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL,
  `isfeatured` enum('Yes','No') NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `sheppingmethod` int(11) NOT NULL,
  `attributes` text NOT NULL,
  `type` enum('Shippable','Virtual') NOT NULL,
  `note` text NOT NULL,
  `imagelist` text NOT NULL,
  `attributegroup` int(11) NOT NULL,
  `attributevalue` text NOT NULL,
  `features` text NOT NULL,
  `supplierprice` text NOT NULL,
  `oldprice` float NOT NULL,
  `qty` float NOT NULL,
  `criticalqty` int(10) NOT NULL,
  `slidetype` varchar(20) NOT NULL,
  `shippingmethod` int(11) NOT NULL,
  `redirectafteradd2card` varchar(100) NOT NULL,
  `downloadfilepath` varchar(100) NOT NULL,
  `relatedproduct` varchar(200) NOT NULL,
  `pagetitle` varchar(255) NOT NULL,
  `pagekeys` varchar(255) NOT NULL,
  `pagedesc` varchar(255) NOT NULL,
  `promotext` varchar(255) NOT NULL,
  `galleryimagelist` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}storecomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `rate` float NOT NULL,
  `dated` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}storeslide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminref` int(11) NOT NULL,
  `entrydate` datetime NOT NULL DEFAULT '2012-12-29 14:51:18',
  `lastmodified` datetime NOT NULL,
  `title` varchar(100) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminref` int(11) NOT NULL,
  `entrydate` datetime NOT NULL DEFAULT '2013-02-22 12:49:06',
  `lastmodified` datetime NOT NULL,
  `title` varchar(100) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `imagepos` enum('Active','Inactive') NOT NULL,
  `imageasbackground` enum('Yes','No') NOT NULL,
  `position` varchar(100) NOT NULL,
  `sortorder` int(11) NOT NULL,
  `url` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}attributegroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminref` int(11) NOT NULL,
  `entrydate` datetime NOT NULL DEFAULT '2013-01-21 00:00:02',
  `lastmodified` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `numoffields` varchar(100) NOT NULL,
  `object` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
-- query
DROP TABLE IF EXISTS {_prefix_}countries;
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminref` int(11) NOT NULL,
  `entrydate` datetime NOT NULL DEFAULT '2012-12-31 18:03:51',
  `lastmodified` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `states` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `shippingstatus` enum('Active','Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=238 DEFAULT CHARSET=utf8;
-- query
INSERT INTO {_prefix_}countries VALUES ('1', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Zimbabwe', 'ZW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('2', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Zambia', 'ZM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('3', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Zaire', 'ZR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('4', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Yemen', 'YE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('5', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Western Sahara', 'EH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('6', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Wallis and Futuna Isl.', 'WF', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('7', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Virgin Islands', 'VI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('8', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Vietnam', 'VN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('9', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Venezuela', 'VE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('10', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Vatican City', 'VA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('11', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Vanuatu', 'VU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('12', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Uzbekistan', 'UZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('13', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Uruguay', 'UY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('14', '1', '2012-12-31 18:03:51', '2013-01-03 01:19:02', 'United States', 'US', '{
  ''AL'': ''Alabama'', 
  ''AK'': ''Alaska'', 
  ''AZ'': ''Arizona'', 
  ''AR'': ''Arkansas'', 
  ''CA'': ''California'', 
  ''CO'': ''Colorado'', 
  ''CT'': ''Connecticut'', 
  ''DE'': ''Delaware'', 
  ''DC'': ''District of Columbia'', 
  ''FL'': ''Florida'', 
  ''GA'': ''Georgia''
}
', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('15', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'United Kingdom', 'GB', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('16', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'United Arab Emirates', 'AE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('17', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Ukraine', 'UA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('18', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Uganda', 'UG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('19', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Tuvalu', 'TV', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('20', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Turks and Caicos Isl.', 'TC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('21', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Turkmenistan', 'TM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('22', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Turkey', 'TR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('23', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Tunisia', 'TU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('24', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Trinidad and Tobago', 'TT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('25', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Tonga', 'TO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('26', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Tokelau', 'TK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('27', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Togo', 'TG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('28', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Thailand', 'TH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('29', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Tanzania', 'TZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('30', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Tajikistan', 'TJ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('31', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Taiwan', 'TW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('32', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Syrian Arab Republic', 'SY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('33', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Switzerland', 'CH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('34', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Sweden', 'SE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('35', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Swaziland', 'SZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('36', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Svalbard', 'VB', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('37', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Suriname', 'SR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('38', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Sudan', 'SD', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('39', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Sri Lanka', 'LK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('40', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Spain', 'ES', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('41', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'South Africa', 'ZA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('42', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Somalia', 'SO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('43', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Solomon Islands', 'SB', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('44', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Slovenia', 'SI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('45', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Slovakia', 'SK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('46', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Singapore', 'SG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('47', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Sierra Leone', 'SL', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('48', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Seychelles', 'SC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('49', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Serbia + Montenegro', 'EM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('50', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Senegal', 'SN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('51', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Saudi Arabia', 'SA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('52', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Sao Tome and Princ.', 'ST', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('53', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'San Marino', 'SM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('54', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Samoa', 'WS', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('55', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Saint Vincent', 'VC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('56', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Saint Pierre', 'SP', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('57', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Saint Lucia', 'LC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('58', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Saint Kitts and Nevis', 'KN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('59', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Saint Helena', 'SH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('60', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Rwanda', 'RW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('61', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Russian Federation', 'RU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('62', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Romania', 'RO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('63', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Reunion', 'RE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('64', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Qatar', 'QA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('65', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Puerto Rico', 'PR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('66', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Portugal', 'PT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('67', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Poland', 'PL', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('68', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Pitcairn', 'PN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('69', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Philippines', 'PH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('70', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Peru', 'PE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('71', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Paraguay', 'PU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('72', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Papua New Guinea', 'PG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('73', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Panama', 'PA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('74', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Palau', 'PW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('75', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Pakistan', 'PK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('76', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Oman', 'OM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('77', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Norway', 'NO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('78', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Northern Mariana Islands', 'MP', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('79', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Norfolk Island', 'NF', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('80', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Niue', 'NU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('81', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Nigeria', 'NG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('82', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Niger', 'NE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('83', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Nicaragua', 'NI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('84', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'New Zealand', 'NZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('85', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'New Caledonia', 'NC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('86', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Netherlands Antilles', 'AN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('87', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Netherlands', 'NL', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('88', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Nepal', 'NP', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('89', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Nauru', 'NR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('90', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Namibia', 'NA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('91', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Myanmar', 'MM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('92', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Mozambique', 'MZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('93', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Morocco', 'MA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('94', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Montserrat', 'MS', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('95', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Montenegro', 'ME', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('96', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Mongolia', 'MN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('97', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Monaco', 'MC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('98', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Moldova', 'MD', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('99', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Micronesia', 'MI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('100', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Mexico', 'MX', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('101', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Mayotte', 'YT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('102', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Mauritius', 'MU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('103', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Mauritania', 'MR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('104', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Martinique', 'MQ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('105', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Marshall Islands', 'MH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('106', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Malta', 'MT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('107', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Mali', 'ML', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('108', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Maldives', 'MV', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('109', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Malaysia', 'MY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('110', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Malawi', 'MW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('111', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Madagascar', 'MG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('112', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Macedonia', 'MK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('113', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Macau', 'MO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('114', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Luxembourg', 'LU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('115', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Lithuania', 'LT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('116', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Liechtenstein', 'LI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('117', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Libyan Arab Jamahiriya', 'LY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('118', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Liberia', 'LR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('119', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Lesotho', 'LS', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('120', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Lebanon', 'LB', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('121', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Latvia', 'LV', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('122', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Laos', 'LO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('123', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Kyrgyzstan', 'KG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('124', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Kuwait', 'KW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('125', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Kosovo', 'KO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('126', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Korea', 'KP', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('127', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Kiribati', 'KI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('128', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Kenya', 'KE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('129', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Kazakhstan', 'KZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('130', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Jordan', 'JO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('131', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Japan', 'JP', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('132', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Jamaica', 'JM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('133', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Italy', 'IT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('134', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Israel', 'IL', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('135', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Ireland', 'IE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('136', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Iraq', 'IQ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('137', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Iran', 'IR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('138', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Indonesia', 'ID', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('139', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'India', 'IN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('140', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Iceland', 'IS', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('141', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Hungary', 'HU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('142', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Hong Kong', 'HK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('143', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Honduras', 'HN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('144', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Heard and McD. Isl.', 'HE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('145', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Haiti', 'HT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('146', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Guyana', 'GY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('147', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Guinea-Bissau', 'GW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('148', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Guinea', 'GN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('149', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Guatemala', 'GT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('150', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Guam', 'GU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('151', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Guadeloupe', 'GP', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('152', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Grenada', 'GD', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('153', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Greenland', 'GL', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('154', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Greece', 'GR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('155', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Gibraltar', 'GI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('156', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Ghana', 'GH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('157', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Germany', 'DE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('158', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Georgia', 'GE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('159', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Gambia', 'GM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('160', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Gabon', 'GA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('161', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'French Southern Terr.', 'FT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('162', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'French Polynesia', 'PF', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('163', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'French Guiana', 'GF', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('164', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'France', 'FR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('165', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Finland', 'FI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('166', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Fiji', 'FJ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('167', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Faroe Islands', 'FO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('168', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Falkland Islands', 'FK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('169', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Ethiopia', 'ET', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('170', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Estonia', 'EE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('171', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Eritrea', 'ER', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('172', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Equatorial Guinea', 'GQ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('173', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'El Salvador', 'SV', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('174', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Egypt', 'EG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('175', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Ecuador', 'EC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('176', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'East Timor', 'TP', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('177', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Dominican Republic', 'DO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('178', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Dominica', 'DM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('179', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Djibouti', 'DJ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('180', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Denmark', 'DK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('181', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Czech Republic', 'CZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('182', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cyprus', 'CY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('183', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Curaco', 'CC', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('184', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cuba', 'CU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('185', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Croatia', 'HR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('186', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cote d Ivoire', 'CI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('187', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Costa Rica', 'CR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('188', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cook islands', 'CK', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('189', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Congo (Dem Rep of the)', 'CG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('190', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Comoros', 'KM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('191', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Colombia', 'CO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('192', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cocos Islands', 'CS', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('193', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Christmas Island', 'CX', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('194', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'China', 'CN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('195', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Chile', 'CL', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('196', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Chad', 'TD', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('197', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Central African Republic', 'CF', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('198', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cayman Islands', 'KY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('199', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cape Verde', 'CV', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('200', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Canada', 'CA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('201', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cameroon', 'CM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('202', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:34', 'Cambodia', 'KH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('203', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Burundi', 'BI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('204', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Burkina Faso', 'BF', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('205', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bulgaria', 'BG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('206', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Brunei Darussalam', 'BN', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('207', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'British Indian Ocean', 'IO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('208', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Brazil', 'BR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('209', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bouvet Island', 'BV', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('210', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Botswana', 'BW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('211', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bosnia and Herzegowina', 'BA', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('212', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bolivia', 'BO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('213', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bhutan', 'BT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('214', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bermuda', 'BM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('215', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Benin', 'BJ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('216', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Belize', 'BZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('217', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Belgium', 'BE', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('218', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Belarus', 'BY', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('219', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Barbados', 'BB', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('220', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bangladesh', 'BD', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('221', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bahrain', 'BH', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('222', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Bahamas', 'BS', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('223', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Azerbaijan', 'AZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('224', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Austria', 'AT', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('225', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Australia', 'AU', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('226', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Aruba', 'AW', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('227', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Armenia', 'AM', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('228', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Argentina', 'AR', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('229', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Antigua and Barbuda', 'AG', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('230', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Antarctica', 'AQ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('231', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Anguilla', 'AI', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('232', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Angola', 'AO', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('233', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Andorra', 'AD', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('234', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'American Samoa', 'AS', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('235', '1', '2012-12-31 18:03:51', '2013-01-01 13:56:35', 'Algeria', 'DZ', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('236', '1', '2012-12-31 18:03:51', '2013-03-02 00:35:13', 'Albania', 'AL', '', 'Active', 'Active');
-- query
INSERT INTO {_prefix_}countries VALUES ('237', '1', '2012-12-31 18:03:51', '2013-03-02 00:35:24', 'Afghanistan', 'AF', '', 'Inactive', 'Active');
-- query
CREATE TABLE IF NOT EXISTS `{_prefix_}discountcoupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminref` int(11) NOT NULL,
  `entrydate` datetime NOT NULL DEFAULT '2013-01-09 14:55:39',
  `lastmodified` datetime NOT NULL,
  `batchname` varchar(50) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `calmethod` enum('flatamount','percentage') NOT NULL,
  `status` enum('Active','Inactive','Redeemed') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
