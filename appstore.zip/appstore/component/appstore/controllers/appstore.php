<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */
class appstoreController extends appRain_Base_Core
{
    const ITEM_PER_PATE = 12;
    public $name = 'appStore';
    public $dispatch =  Array( 
        'preDispatchExclude'=>array(),
        'postDispatchExclude'=>array()
	);

    /**
     * This function run before each
     * Action Method
     */
    public function __preDispatch()
    {
        $this->page_title = App::Config()->setting('appstoresettings_title');
        $this->set("section_title",App::Config()->setting('appstoresettings_title'));
        $this->set("selected","store");
    }

    /**
     * Render Store product display page
     * - URL are customize by
     *   URI_Manager >> Page_Router
     */
    public function indexAction($action=null, $id=null, $page=1)
    { 
		
        /* Set page meta information */
		$this->addons = array('appcart');
        $this->staticPageNameToMetaInfo('store');
        if($action == 'bycat') {
       	
            $products = App::InformationSet('product')
                ->paging(
                    "category LIKE '%{$id}%' ORDER BY entrydate DESC"
                );

            $this->set('products',$products);
			$Category = App::CategorySet()->findById($id);
            $this->page_title = $Category['title'];
            $this->set("section_title",$Category['title']);
            $this->set("catid",$id);
            $this->set("Category",$Category);
        }
        else if($action == 'byprod'){
           
            $product = App::InformationSet('product')->findById($id);
			$this->setProudctMetaData($product);
			
            $this->set("section_title",App::CategorySet()->idToName($product['category']));

			$comments = App::Model('StoreComment')->paging(
				"productid={$id} AND status='Active'",
				15
			);
            $this->set('comments',$comments);
			
            $this->set('product',$product);
            $this->set("catid",$product['category']);
         
        }
        else {
            // Fetch all Featured Products
            $page = is_numeric($action) ? $action : 1;
            $products = App::InformationSet('product')
                ->findAll("isfeatured='Yes' and status='Active' ORDER BY entrydate DESC");
            $this->set('products',$products);
            $this->set("catid","");
        }
        
        $storeslides = App::InformationSet('storeslide')
            ->setPagination('No')
            ->findAllByStatus('Active');
			
        $this->set('storeslides',$storeslides);
        $this->set("action",$action);
        $this->set("id",$id);
    }

	private function setProudctMetaData($product){
		
		$this->page_title =  App::CategorySet()->idToName($product['category']) . ' | ' . $product['title'];
		
		if($product['pagetitle'] !=''){
			$this->page_title = $product['pagetitle'];
		}
		
		if($product['pagekeys'] !=''){
			$this->page_meta_keyowrds = $product['pagekeys'];
		}

		if($product['pagedesc'] !=''){
			$this->page_meta_desc = $product['pagedesc'];
		}
	}
	
    private function itemperpage()
    {
        $itemperpage = App::Config()->siteInfo('appstoresettings_itemperpage',false);
        return ($itemperpage) ? $itemperpage : self::ITEM_PER_PATE;
    }

    /**
     * Function called by AJAX Request
     * Add/Update product to cart
     */
    public function add2qcartAction($pid=null,$qty=null)
    {
        if(!isset($this->get['ajax']))$this->redirect('/');

        $this->layout = 'empty';
		$this->data['Attribute'] = isset($this->data['Attribute']) ? $this->data['Attribute'] : array();
		$Product = App::InformationSet('Product')->findById($pid);
		
        try {
            App::Component('appStore')
                ->Helper('Data')
				->setAttribute($this->data['Attribute'])
                ->quickAdd($pid,$qty);

            $totalitem = App::Component('appStore')
                 ->Helper('Data')
                 ->getCartTotalItem();

			if(!empty($Product['redirectafteradd2card'])){
				$url = str_replace('[id]',$Product['id'],App::Utility()->codeFormated($Product['redirectafteradd2card']));
				echo App::Load("Module/Cryptography")->jsonEncode(
					Array(
						"_status" =>"Redirect",
						"_url"=> $url
						)
				);
			}
            else{
				echo App::Load("Module/Cryptography")->jsonEncode(
					Array(
						"_status" =>"Success",
						"_hastocheckout"=>  App::Component('appStore')
							->Helper('Data')
							->isToCheckout(),
							"totalitem"=>$totalitem,
							"_message"=>$this->__('Cart updated successfully.')
						)
				);
			}
        }
        catch (AppException $e) {
            echo App::Load("Module/Cryptography")->jsonEncode(array( "_status" =>"Error", "_message"=>$e->getMessage()));
        }

    }

    /**
     * Render the checkout page
     */
    public function checkoutAction($action=null, $id=null)
    {
		if(!empty($this->data)){
			$appcart = App::Session()->Read('appcart');
			foreach($appcart as $_pid=>$_cart){
				$appcart[$_pid]['qty'] = $this->data['qty'][$_pid];
			}
			$appcart = App::Session()->Write('appcart',$appcart);
			$this->redirect("/appstore/checkout");
		}
        // Set Meta information of the page
        $this->staticPageNameToMetaInfo('checkout');

        // Attached all addons need for this section
        $this->addons = Array('datagrid');

        $cartinfo = App::Component('appStore')->Helper('Data')->getCartInfo();
        if(empty($cartinfo)) {
            $this->redirect("/store");
            exit;
        }

        // Remove Items from cart
        if($action=='removeitem') {
            App::Component('appStore')
                ->Helper('Data')
                ->removeItem($id);
            $this->redirect("/checkout");
            exit;
        }

        $this->set("section_title","Checkout");
    }
    /**
     * Function called by ajax Request to
     * Complete the Checkout process
     */
    public function completeCheckoutAction()
    {
        $this->layout = 'empty';
        if(empty($this->data)) {
            $this->redirect('/');
            exit;
        }
	
        try {
            // This call complete the Checkout process and also
            // execute payment processor. We used some magic
            // Functions to set data easily in inner blocks
            //
            // If any Function throw any Excepion from anywhere
            // then program control move in Catch Section without executing
            // rest part of the coding flow. This process
            // helps you to add as many payment processory you need
            // that controll the Checkout operation.
            // For help: www.apprain.com/ticket
            App::Component('appStore')->Helper('Data')
               // This is a magic method to set post data . Data can be
               // retrived by $this->getCheckoutPostData(). This function
               // return object of own class to mantain the chain of other call.
               ->setCheckoutPostData($this->data)
               ->organiseResource()
               ->orderValidation()
               // Start checkout Process and execute payment processor. This funtion throw
               // exception for any Invalid Result and stop all further execution
               ->StartCheckoutProcess()
               // Change the order status changed to PAID as no exception thrown from previouse
               // function.
               ->ChnageOrderStatus()
               // Clear cart SESSION.
               ->clearcart();

            // Return to Payment Success page
            echo App::Load("Module/Cryptography")->jsonEncode(array("_status" =>"Redirect","_location"=>$this->baseUrl("/payment-success")));
        }
        catch (AppException $e) {
            echo App::Load("Module/Cryptography")->jsonEncode(array( "_status" =>"Error", "_message"=>$e->getMessage()));
        }
    }

    /**
     * Display Order status pages
     */
    public function statusmessageAction($status=null)
    {
        if(!isset($status)) {
            $this->redirect("/");
            exit;
		}

        $page_content = $this->staticPageNameToMetaInfo($status);
        $this->set( 'page_content' ,$page_content );
        $this->set("section_title",$this->__("Payment Process"));
        $this->set("selected","store");
		
		$products = App::InformationSet('product')->findAll("isfeatured='Yes' and status='Active' ORDER BY entrydate DESC");
        $this->set('products',$products);			
    }

	
	
	public function getStateBoxAction($type=null,$code=null){
		$this->layout = 'empty';
		
		App::Session()->Write('shipping_country_code',$code);
		
		$data = array(
			'statebox'=>App::Component('appstore')->helper('Checkout')->getStateBox($code,"data[" . ucfirst($type) . "][state]",null,array("class"=>"form-control check_notempty")),
			'chckoutsummaryhtml' => App::Component('appstore')->helper('Checkout')->getChckoutSummaryHtml()
		);
		
		echo App::Module('Cryptography')->jsonEncode($data);
	}
	
	public function submitdiscountcodeAction($code=null){
		$this->layout = 'empty';	
		try{
			
			App::Component('appstore')->helper('Checkout')->executeCouponCode($code);		
			throw new AppException('Success');
		}
        catch (AppException $e) {
			echo App::Module('Cryptography')
				->jsonEncode(
				array(
					'response'=> $e->getMessage(),
					'chckoutsummaryhtml' => App::Component('appstore')->helper('Checkout')->getChckoutSummaryHtml($code)
				)
			);
        }
	}
			
	public function checkAttributeForValueAction($id=null,$requestkey=null){
		$this->layout ='empty';
		try {	
			$Attributes = $this->data['Attribute'];
			
			$Product = App::InformationSet('product')->findById($id);
			### Allow buy other product
			###$Products = App::InformationSet('product')->findAll("attributegroup={$Product['attributegroup']} and id<>{$id}");
			$Products = App::InformationSet('product')->findAll("id={$id}");
			$Products = array_merge(array($Product),$Products['data']);
			
			
			foreach($Products as $row){
				$attributevalues = unserialize($row['attributevalue']);
				$flag = true;
				$maxQty = "";
				foreach($Attributes as $key=>$value){
					if(isset($attributevalues[$key])){
						$checkData = (is_array($attributevalues[$key]['value'])) ? $attributevalues[$key]['value'] : array($attributevalues[$key]['value']);
						if(!in_array($value,$checkData)){
							$flag = false;
						}
						if($flag && isset($attributevalues[$key])){
							$qty = $this->findQuantity($attributevalues[$key]['qty'],$checkData,$value);
							if($qty != ""){
								if($maxQty == '' || $maxQty > $qty){
									$maxQty = $qty;
								}
							}
							
							if("{$qty}" !=="" and (int)$qty <= 0){
								throw new AppException('SOLD');
							}
						}					
					}
				}
				
				if($flag){
					throw new AppException();
				}	
			}		
			
			throw new AppException('NO_ITEM_FOUND'); 
		}
        catch (AppException $e){

			if($e->getMessage()){
				$suggession = '';
				$MSG_CODE = $e->getMessage();
				//if($e->getMessage() != 'SOLD')
				{
					$suggession = App::Component('Appstore')->Helper('Common')->getAttributeSuggession($requestkey,$Attributes,$id);
				}
				echo  				
					App::Module('Cryptography')
						->jsonEncode(
							array(
								'status'=>'Faield',
								'price'=>App::Component('Appstore')->Helper('Common')->getPricebox($row),
								'maxqty'=> (string) $maxQty,
								"message"=> App::Component('appStore')->Helper('Data')->getCartMessage($MSG_CODE),
								'suggession' =>(string) $suggession,
								'presentationpox' => ''
							)
						);
			}
			else {
				echo  				
					
					App::Module('Cryptography')
						->jsonEncode(
							array(
								'status'=>'Success',
								'id'=>$row['id'],
								'price'=>App::Component('Appstore')->Helper('Common')->getPricebox($row),
								'maxqty'=> $maxQty,
								'presentationpox' => ($id == $row['id']) ? '' : App::Component('appStore')->Helper('Common')->productPresentationBox($row)
							)
						);
			}
		}
	}
	
	private function findQuantity($chkData,$arr,$value){
		$maxQty = '';		
		foreach($arr as $i=>$v){
			if($v == $value){
				if($chkData[$i] !=''){
					if(($maxQty==='') or ($chkData[$i] < $maxQty)){
						$maxQty = (string)$chkData[$i];
					}
				}
			}
		}	
		return $maxQty;
	}
	
	public function customer_reviewAction($id=null){
	
		if(empty($this->data)){
			$this->redirect("/");
		}
		
        // Set Empty Layout
        $this->layout = 'empty';

        try {
            $capacha = App::Module('Session')->read('capacha');

            if($capacha['storecommet'] != $this->data['StoreComment']['capacha']){
                throw new AppException($this->__("Please fillin the text display left side image correctly."));
            }
            // Save Comments
            // Please apply more logic if you needed
            $this->data['StoreComment']['productid'] = $id;
            $this->data['StoreComment']['status'] = 'Inactive';
            $this->data['StoreComment']['ip'] = App::Config()->getServerInfo('REMOTE_ADDR');			
            $this->data['StoreComment']['dated'] = App::Helper('Date')->getDate("Y-m-d H:i:s");
			
            $obj = App::Model('StoreComment')->Save($this->data);
			
            // Send Email notification using
            // Template Manager Helper
            App::Helper('EmailTemplate')
				->setParameters(
					Array(
						'Name'=>$this->data['StoreComment']['name'],
						'Comment'=>$this->data['StoreComment']['comment'],
						'EmailAddress'=>$this->data['StoreComment']['email']
					)
				)
                ->prepare('StoreComment',true);

            $status = 'Success';
            throw new AppException($this->__("Thank you, Your comment is waiting for approval."));
        }
        catch (AppException $e){
            // Catch exceptions and display message
            // in JSON format using Cryptography Helper
			$status = (isset($status) ? $status : 'Error');
            echo App::Load("Module/Cryptography")
				->jsonEncode(
					array(
						"_status" =>(isset($status) ? $status : 'Error'),
						"_message"=> App::Html()->getTag('span',array('class'=>strtolower($status)),$e->getMessage())
					)
				);
        }
	}
	
	public function downloadAction($key=null){
		
		$this->layout = 'empty';
		if(!isset($key)){
			$this->redirect();
		}
		
		$KeyDecrypted = base64_decode($key);
		$KeyDecrypted = explode('O',$KeyDecrypted);
		
		if(count($KeyDecrypted) != 2){
			$this->redirect();
		}
		
		$Order = App::Model('Order')->findById($KeyDecrypted[0]);
		if(strtolower($Order['paymentstatus']) != 'paid'){
			App::Config()->transfer($this->baseUrl("/"),"Download is protected due to payment issue.");
			exit;
		}
		
		$Product = App::InformationSet('Product')->findById($KeyDecrypted[1]);
		if(empty($Order) OR empty($Product)){
			$this->redirect();
		}		
		
		$time = time()-strtotime($Order['orderdate']);
		$days = round($time/(60*60*24));
		if($days > 7 ){
			$this->redirect();
		}
		
		
		
		if(strstr($Product['downloadfilepath'],'/') || strstr($Product['downloadfilepath'],'\\')){
			$downloadfilepath = $Product['downloadfilepath'];
		}
		else{
			$downloadfilepath = App::Component('Appstore')->Helper('Data')->getResourcePath('virtualproduct') . DS;
		}
		
		$path = $downloadfilepath . $Product['downloadfilepath'];
		if(file_exists($path)){
			App::Utility()->download($path,App::Utility()->getExt($Product['downloadfilepath']),$Product['title']);
		}
		else{
			App::Config()->transfer($this->baseUrl("/"),"Sorry! Download resource is temporarily unavailable, Try after sometime.");
		}
		exit;
	}
	
	public function personalizeAction($id){
		 $this->set("section_title",'Personalize your card');
		 $cartData = App::Session()->Read('appcart');
		 if(!empty($this->data)){			
			foreach($this->data['PostCard'] as $name=>$value){
				$cartData[$id]['attributes']['postcard_' . $name] = array(
					'title' => $name,'value'=>$value
				);
			}
			$cartData = App::Session()->Write('appcart',$cartData);
			
			echo App::Load("Module/Cryptography")->jsonEncode(
					Array(
						"_status" =>"Redirect",
						"_location"=> $this->baseUrl("/appstore/checkout"))
				);
				exit;
		 }	
		 $this->set('cartdata',$cartData[$id]);
		 $Product = App::InformationSet('product')->findById($id);
		 $this->set('Product',$Product);
		 $this->set('id',$id);		 
	}
}
