<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Register extends appRain_Base_Component
{
    public function init()
    {
		App::Module('Hook')
			->setHookName('Sitemenu')
			->setAction("register_sitemenu")
			->Register(get_class($this),"register_sitemenu");

		App::Module('Hook')
			->setHookName('Controller')
			->setAction("register_controller")
			->Register(get_class($this),"register_controller");


		App::Module('Hook')
			->setHookName('InformationSet')
			->setAction("register_definition")
			->Register(get_class($this),"register_informationset_defination");

		App::Module('Hook')
			->setHookName('CategorySet')
			->setAction("register_definition")
			->Register(get_class($this),"register_categoryset_defination");

		App::Module('Hook')
			->setHookName('InterfaceBuilder')
			->setAction("register_definition")
			->Register(get_class($this),"register_interface_builder_defination");

		App::Module('Hook')
			->setHookName('Sitesettings')
			->setAction("register_definition")
			->Register(get_class($this),"register_sitesettings_defination");

		App::Module('Hook')
			->setHookName('Model')
            ->setAction("register_model")
			->Register(get_class($this),"register_model");

		App::Module('Hook')
			->setHookName('URIManager')
			->setAction("on_initialize")
			->Register(get_class($this),"register_newrole");

		App::Module('Hook')
			->setHookName('Helper')
			->setAction("register_helper")
			->Register(get_class($this),"register_helper");

		App::Module('Hook')
			->setHookName('UI')
            ->setAction("template_header_B")
            ->Register(get_class($this),"add_cart_link");
						   
		App::Module('Hook')
            ->setHookName('UI')
            ->setAction("home_content_area_A")
            ->Register(get_class($this),"add_html");	

		App::Module('Hook')->setHookName('Addon')
            ->setAction("register_addon")
            ->Register(get_class($this),"register_addon_defination");

        $this->register_detail_acl_definition();
    }

	public function register_admin_notification($e)
	{
		$messages = Array();
		$messages[] = array($this->__("Two commets waiting for approval.."),array('type'=>'admin-notice','level'=>'Warning'));
		return $messages;
	}

    public function init_on_install()
	{
		# Register Admin TAB
		$this->autoRegisterAdminTopNav('catalog');
		
		# Install Dummy data
		App::Component('appStore')
			->Helper('dummyData')
			->generateCommonData();
	}

	public function init_on_uninstall()
	{
	}

    public function register_detail_acl_definition(){
        App::Module('ACL')->register(
            array('appstore'=>'Store'),
            array(
                'orderaccess'=>array(
                    'title'=>'Order Process',
                    'inputtype'=>'checkboxTag',
                    'options' => array('view'=>'View','edit'=>'Edit','delete'=>'Delete'),
                    'defaultvalue'=>'view,edit'
                ),
                'paymentmethod'=>array(
                    'title'=>'Payment Methods Access',
                    'inputtype'=>'radioTag',
                    'options' => array('enable'=>'Enable','disabled'=>'Disabled'),
                    'defaultvalue'=>'disabled'
                )
            )
        );
    }

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array(
			'name'=>'appStore',
            'controller_path'=>$this->attachMyPath('controllers')
		);
		$srcpaths[] =   array(
			'name'=>'manageStore',
            'controller_path'=>$this->attachMyPath('controllers')
		);
        return $srcpaths;
    }

	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = array(
			'type'=>'Product',
			'path'=>$this->attachMyPath('information_set/product.xml')
		);
        
		$srcpaths[] = array(
			'type'=>'storeslide',
			'path'=>$this->attachMyPath('information_set/storeslide.xml')
		);							   		
        
		$srcpaths[] = array(
			'type'=>'countries',
			'path'=>$this->attachMyPath('information_set/countries.xml')
		);
        
		$srcpaths[] = array(
			'type'=>'discountcoupon',
			'path'=>$this->attachMyPath('information_set/discountcoupon.xml')
		);
        
		$srcpaths[] = array(
			'type'=>'attributegroup',
			'path'=>$this->attachMyPath('information_set/attributegroup.xml')
		);
        
		$srcpaths[] = array(
			'type'=>'widget',
			'path'=>$this->attachMyPath('information_set/widget.xml')
		);

        return $srcpaths;
    }

	public function register_categoryset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = array(
			'type'=>'product-cat',
			'path'=>$this->attachMyPath('category_set/product-cat.xml')
		);
        
		$srcpaths[] = array(
			'type'=>'shippingrole',
			'path'=>$this->attachMyPath('category_set/shippingrole.xml')
		);
        
		return $srcpaths;
    }

	public function register_interface_builder_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('interface_builder/catalog.xml');
        return array('filepaths'=>$srcpaths);
    }

	public function register_model()
    {
        $srcpaths = Array();
        $srcpaths[] =   array(
			'name'=>'Item',
            'model_path'=>$this->attachMyPath('models')
		);

		$srcpaths[] = array(
			'name'=>'Order',
            'model_path'=>$this->attachMyPath('models')
		);

		$srcpaths[] = array(
			'name'=>'storeComment',
            'model_path'=>$this->attachMyPath('models')
		);

        return $srcpaths;
    }

	public function register_sitemenu($send)
	{
		$menu = Array();
		$menu[] = Array(
			App::Helper('Config')->baseurl("/store"),
			App::COnfig()->Setting('appstoresettings_title','Store'),
			'store'
		);
		return $menu;
	}

	public function register_newrole($def=null)
    {
        if(App::Config()->Setting('appstoresettings_make_store_homepage','Yes') == 'Yes'){
            $def['bootrouter']['controller'] = 'appstore';
            $def['bootrouter']['action'] = 'index';
        }
        
        $def['pagerouter'][] = array(
			"actual"=>Array("appstore","index"),
			"virtual"=>Array("store")
		);
		
		$def['pagerouter'][] = array(
			"actual"=>Array("appstore","index","bycat"),
			"virtual"=>Array("category-view")
		);
		
		$def['pagerouter'][] = array(
			"actual"=>Array("appstore","index","byprod"),
			"virtual"=>Array("item-detail")
		);
		
		$def['pagerouter'][] = array(
			"actual"=>Array("appstore","checkout"),
			"virtual"=>Array("checkout")
		);

		$def['pagerouter'][] = array(
			"actual"=>Array("appstore","statusmessage","payment-success"),
			"virtual"=>Array("payment-success")
		);
		
		$def['pagerouter'][] = array(
			"actual"=>Array("appstore","statusmessage","payment-failed"),
			"virtual"=>Array("payment-failed")
		);

        return $def;
    }

	public function register_helper()
    {
        //Default path
    }

	public function register_sitesettings_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('sitesettings/settings.xml');
        return array('filepaths'=>$srcpaths);
    }

	public function add_cart_link($send)
	{
		$Config = App::Helper('COnfig');
		$html  = "";
		$html .= '<li class="tcartinfo">';
		$html .= App::Helper('Html')
			->linkTag($Config->baseUrl("/checkout"),
				$this->__('Cart') . ' (<span id="tqtycart">'  .
				App::Component('appStore')->Helper('Data')->getCartTotalItem() .
				'</span>)'
			);
		$html .= '</li>';
		return $html;
	}
	
    public function add_html($send)
    {
        $products = App::InformationSet('product')->findAll('isfeatured="Yes" ORDER BY RAND() limit 0,6');
		
        return App::Helper('Utility')
            ->callElementByPath(
                $this->attachMyPath('elements/updates.phtml'),
                array('products'=>$products)
        );
		
    }	

	public function register_addon_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array(
			'type'=>'appstore',
            'path'=>$this->attachMyPath('addons/appstore.xml')
		);
        return $srcpaths;
    }	
}